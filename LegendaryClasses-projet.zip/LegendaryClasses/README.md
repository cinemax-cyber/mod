# LegendaryClasses (Paper 1.21.11, Java 21)

Compiler : `mvn clean package` -> `target/LegendaryClasses-1.0.0.jar`
Sans rien installer : poussez ce dossier sur GitHub, l'onglet Actions produit le JAR (.github/workflows/build.yml).
Plugin Paper uniquement (pas Forge/NeoForge/Fabric). Publication : Modrinth (loader Paper) / CurseForge (Bukkit Plugins).
