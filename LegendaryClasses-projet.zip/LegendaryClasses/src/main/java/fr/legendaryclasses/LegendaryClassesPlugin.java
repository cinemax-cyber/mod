package fr.legendaryclasses;

import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.command.ClassCommand;
import fr.legendaryclasses.data.PlayerDataManager;
import fr.legendaryclasses.experience.ExperienceListener;
import fr.legendaryclasses.experience.ExperienceManager;
import fr.legendaryclasses.listener.PlayerConnectionListener;
import fr.legendaryclasses.listener.SkillListener;
import fr.legendaryclasses.menu.MenuManager;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.util.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.PluginCommand;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class LegendaryClassesPlugin extends JavaPlugin {

    private MessageManager messageManager;
    private PlayerDataManager dataManager;
    private ClassManager classManager;
    private ExperienceManager experienceManager;
    private SkillManager skillManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        saveDefaultConfig();

        messageManager = new MessageManager(this);
        messageManager.load();

        dataManager = new PlayerDataManager(this);
        if (!dataManager.init()) {
            getLogger().severe("Impossible d'initialiser la base SQLite. Désactivation du plugin.");
            getServer().getPluginManager().disablePlugin(this);
            return;
        }

        classManager = new ClassManager(this);
        experienceManager = new ExperienceManager(this);
        experienceManager.reload();
        skillManager = new SkillManager(this);
        skillManager.reload();
        menuManager = new MenuManager(this);

        getServer().getPluginManager().registerEvents(new PlayerConnectionListener(this), this);
        getServer().getPluginManager().registerEvents(new ExperienceListener(this), this);
        getServer().getPluginManager().registerEvents(new SkillListener(this), this);
        getServer().getPluginManager().registerEvents(menuManager, this);

        ClassCommand classCommand = new ClassCommand(this);
        registerCommand("classe", classCommand);
        registerCommand("classes", classCommand);

        for (Player player : Bukkit.getOnlinePlayers()) {
            dataManager.loadBlocking(player.getUniqueId(), player.getName());
        }
        dataManager.startAutosave();

        getLogger().info("LegendaryClasses activé.");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) {
            dataManager.shutdown();
        }
    }

    private void registerCommand(String name, ClassCommand executor) {
        PluginCommand command = getCommand(name);
        if (command == null) {
            getLogger().severe("Commande absente de plugin.yml : " + name);
            return;
        }
        command.setExecutor(executor);
        command.setTabCompleter(executor);
    }

    /** Recharge config.yml et messages.yml (sans toucher aux fichiers sur le disque). */
    public void reloadAll() {
        reloadConfig();
        messageManager.load();
        experienceManager.reload();
        skillManager.reload();
    }

    public MessageManager getMessageManager() { return messageManager; }
    public PlayerDataManager getDataManager() { return dataManager; }
    public ClassManager getClassManager() { return classManager; }
    public ExperienceManager getExperienceManager() { return experienceManager; }
    public SkillManager getSkillManager() { return skillManager; }
    public MenuManager getMenuManager() { return menuManager; }
}
