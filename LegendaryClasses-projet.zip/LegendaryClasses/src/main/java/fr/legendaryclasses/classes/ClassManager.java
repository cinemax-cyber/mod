package fr.legendaryclasses.classes;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.skill.SkillType;
import fr.legendaryclasses.util.MessageManager;
import fr.legendaryclasses.util.SoundUtil;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public final class ClassManager {

    public enum ChooseResult { SUCCESS, ALREADY_HAS_CLASS }

    private final LegendaryClassesPlugin plugin;
    private final Map<UUID, Long> pendingResets = new HashMap<>();

    public ClassManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    // ---------- Textes ----------

    public String getDisplayName(ClassType type) {
        return messages().raw("classes." + type.getId() + ".name");
    }

    public String getSpecialty(ClassType type) {
        return messages().raw("classes." + type.getId() + ".specialty");
    }

    public List<String> getDescription(ClassType type) {
        return messages().rawList("classes." + type.getId() + ".description");
    }

    public String getSkillName(SkillType skill) {
        return messages().raw("skills." + skill.getId() + ".name");
    }

    public String getSkillDescription(SkillType skill) {
        return messages().raw("skills." + skill.getId() + ".description");
    }

    // ---------- Déblocage ----------

    public int getUnlockLevel(SkillType skill) {
        return Math.max(1, plugin.getConfig().getInt(skill.getConfigPath() + ".unlock-level", skill.getDefaultUnlockLevel()));
    }

    public boolean isUnlocked(PlayerData data, SkillType skill) {
        return data.getClassType() == skill.getClassType() && data.getLevel() >= getUnlockLevel(skill);
    }

    public List<SkillType> getUnlockedSkills(PlayerData data) {
        List<SkillType> result = new ArrayList<>();
        if (data.getClassType() == null) {
            return result;
        }
        for (SkillType skill : SkillType.forClass(data.getClassType())) {
            if (isUnlocked(data, skill)) {
                result.add(skill);
            }
        }
        return result;
    }

    // ---------- Choix et réinitialisation ----------

    public ChooseResult chooseClass(Player player, PlayerData data, ClassType type) {
        if (data.getClassType() != null) {
            return ChooseResult.ALREADY_HAS_CLASS;
        }
        data.setClassType(type);
        data.setLevel(1);
        data.setXp(0L);
        messages().send(player, "class.chosen", "class", getDisplayName(type));
        SoundUtil.play(player, plugin.getConfig().getString("sounds.class-select"), 1f, 1.2f);
        return ChooseResult.SUCCESS;
    }

    public void requestReset(UUID uuid) {
        pendingResets.put(uuid, System.currentTimeMillis());
    }

    /** Retourne true si une demande de reset valide (non expirée) existait pour ce joueur. */
    public boolean confirmReset(UUID uuid) {
        Long requestedAt = pendingResets.remove(uuid);
        if (requestedAt == null) {
            return false;
        }
        long windowMillis = Math.max(1L, plugin.getConfig().getLong("classes.reset-confirm-seconds", 15L)) * 1000L;
        return System.currentTimeMillis() - requestedAt <= windowMillis;
    }

    public void clearPending(UUID uuid) {
        pendingResets.remove(uuid);
    }

    public void resetPlayer(Player player, PlayerData data) {
        data.reset();
        clearPending(player.getUniqueId());
        SoundUtil.play(player, plugin.getConfig().getString("sounds.reset"), 1f, 1f);
    }

    private MessageManager messages() {
        return plugin.getMessageManager();
    }
}
