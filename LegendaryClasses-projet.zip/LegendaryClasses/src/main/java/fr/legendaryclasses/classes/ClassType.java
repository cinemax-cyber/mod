package fr.legendaryclasses.classes;

import org.bukkit.Material;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

public enum ClassType {

    GUERRIER("guerrier", Material.IRON_SWORD),
    ASSASSIN("assassin", Material.ENDER_PEARL),
    MAGE("mage", Material.BLAZE_ROD),
    ARCHER("archer", Material.BOW),
    FAUCHEUR("faucheur", Material.NETHERITE_HOE);

    private final String id;
    private final Material icon;

    ClassType(String id, Material icon) {
        this.id = id;
        this.icon = icon;
    }

    public String getId() { return id; }

    public Material getIcon() { return icon; }

    /** Accepte la casse libre et ignore les accents. */
    public static Optional<ClassType> fromInput(String input) {
        if (input == null) {
            return Optional.empty();
        }
        String normalized = Normalizer.normalize(input, Normalizer.Form.NFD)
                .replaceAll("\\p{M}", "")
                .toLowerCase(Locale.ROOT)
                .trim();
        for (ClassType type : values()) {
            if (type.id.equals(normalized) || type.name().equalsIgnoreCase(normalized)) {
                return Optional.of(type);
            }
        }
        return Optional.empty();
    }

    public static List<String> ids() {
        List<String> ids = new ArrayList<>();
        for (ClassType type : values()) {
            ids.add(type.id);
        }
        return ids;
    }
}
