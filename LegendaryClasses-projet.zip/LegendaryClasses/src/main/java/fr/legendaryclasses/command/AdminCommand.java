package fr.legendaryclasses.command;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.util.MessageManager;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;

/** Sous-commandes /classe admin ... (les arguments reçus commencent après "admin"). */
public final class AdminCommand {

    private static final String PERM_XP = "legendaryclasses.admin.xp";
    private static final String PERM_LEVEL = "legendaryclasses.admin.level";
    private static final String PERM_RESET = "legendaryclasses.admin.reset";
    private static final String PERM_RELOAD = "legendaryclasses.admin.reload";
    private static final long MAX_ADMIN_XP = 100_000_000L;

    private final LegendaryClassesPlugin plugin;

    public AdminCommand(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean hasAnyPermission(CommandSender sender) {
        return sender.hasPermission(PERM_XP) || sender.hasPermission(PERM_LEVEL)
                || sender.hasPermission(PERM_RESET) || sender.hasPermission(PERM_RELOAD);
    }

    public void execute(CommandSender sender, String[] args) {
        MessageManager messages = plugin.getMessageManager();
        if (!hasAnyPermission(sender)) {
            messages.send(sender, "general.no-permission");
            return;
        }
        if (args.length == 0) {
            messages.send(sender, "usage.admin");
            return;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "xp" -> handleXp(sender, args);
            case "level" -> handleLevel(sender, args);
            case "reset" -> handleReset(sender, args);
            case "reload" -> handleReload(sender);
            default -> messages.send(sender, "usage.admin");
        }
    }

    private void handleXp(CommandSender sender, String[] args) {
        MessageManager messages = plugin.getMessageManager();
        if (!sender.hasPermission(PERM_XP)) {
            messages.send(sender, "general.no-permission");
            return;
        }
        if (args.length < 3) {
            messages.send(sender, "usage.admin-xp");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            messages.send(sender, "general.player-not-found", "player", args[1]);
            return;
        }
        long amount;
        try {
            amount = Long.parseLong(args[2]);
        } catch (NumberFormatException ex) {
            messages.send(sender, "general.invalid-number", "value", args[2]);
            return;
        }
        if (amount <= 0 || amount > MAX_ADMIN_XP) {
            messages.send(sender, "general.invalid-number", "value", args[2]);
            return;
        }
        PlayerData data = plugin.getDataManager().get(target);
        if (data == null) {
            messages.send(sender, "general.data-not-loaded");
            return;
        }
        if (data.getClassType() == null) {
            messages.send(sender, "admin.target-no-class", "player", target.getName());
            return;
        }
        if (data.getLevel() >= plugin.getExperienceManager().getMaxLevel()) {
            messages.send(sender, "admin.target-max-level", "player", target.getName());
            return;
        }
        plugin.getExperienceManager().addExperience(target, data, amount, false);
        messages.send(sender, "admin.xp-given",
                "player", target.getName(), "amount", amount, "level", data.getLevel());
    }

    private void handleLevel(CommandSender sender, String[] args) {
        MessageManager messages = plugin.getMessageManager();
        if (!sender.hasPermission(PERM_LEVEL)) {
            messages.send(sender, "general.no-permission");
            return;
        }
        if (args.length < 3) {
            messages.send(sender, "usage.admin-level");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            messages.send(sender, "general.player-not-found", "player", args[1]);
            return;
        }
        int level;
        try {
            level = Integer.parseInt(args[2]);
        } catch (NumberFormatException ex) {
            messages.send(sender, "general.invalid-number", "value", args[2]);
            return;
        }
        int max = plugin.getExperienceManager().getMaxLevel();
        if (level < 1 || level > max) {
            messages.send(sender, "admin.level-range", "max", max);
            return;
        }
        PlayerData data = plugin.getDataManager().get(target);
        if (data == null) {
            messages.send(sender, "general.data-not-loaded");
            return;
        }
        if (data.getClassType() == null) {
            messages.send(sender, "admin.target-no-class", "player", target.getName());
            return;
        }
        plugin.getExperienceManager().setLevel(target, data, level);
        messages.send(sender, "admin.level-set", "player", target.getName(), "level", level);
    }

    private void handleReset(CommandSender sender, String[] args) {
        MessageManager messages = plugin.getMessageManager();
        if (!sender.hasPermission(PERM_RESET)) {
            messages.send(sender, "general.no-permission");
            return;
        }
        if (args.length < 2) {
            messages.send(sender, "usage.admin-reset");
            return;
        }
        Player target = Bukkit.getPlayerExact(args[1]);
        if (target == null) {
            messages.send(sender, "general.player-not-found", "player", args[1]);
            return;
        }
        PlayerData data = plugin.getDataManager().get(target);
        if (data == null) {
            messages.send(sender, "general.data-not-loaded");
            return;
        }
        plugin.getClassManager().resetPlayer(target, data);
        messages.send(sender, "admin.reset-done", "player", target.getName());
        messages.send(target, "admin.reset-notify");
    }

    private void handleReload(CommandSender sender) {
        MessageManager messages = plugin.getMessageManager();
        if (!sender.hasPermission(PERM_RELOAD)) {
            messages.send(sender, "general.no-permission");
            return;
        }
        plugin.reloadAll();
        plugin.getMessageManager().send(sender, "admin.reload");
    }

    // ---------- Complétion ----------

    public List<String> tabComplete(CommandSender sender, String[] args) {
        if (!hasAnyPermission(sender)) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            List<String> subs = new ArrayList<>();
            if (sender.hasPermission(PERM_XP)) subs.add("xp");
            if (sender.hasPermission(PERM_LEVEL)) subs.add("level");
            if (sender.hasPermission(PERM_RESET)) subs.add("reset");
            if (sender.hasPermission(PERM_RELOAD)) subs.add("reload");
            return filter(subs, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && (sub.equals("xp") || sub.equals("level") || sub.equals("reset"))) {
            List<String> names = new ArrayList<>();
            for (Player player : Bukkit.getOnlinePlayers()) {
                names.add(player.getName());
            }
            return filter(names, args[1]);
        }
        if (args.length == 3 && sub.equals("xp")) {
            return filter(List.of("100", "500", "1000"), args[2]);
        }
        if (args.length == 3 && sub.equals("level")) {
            return filter(List.of("5", "10", "20", "30", "50"), args[2]);
        }
        return Collections.emptyList();
    }

    static List<String> filter(List<String> options, String prefix) {
        String lower = prefix.toLowerCase(Locale.ROOT);
        List<String> result = new ArrayList<>();
        for (String option : options) {
            if (option.toLowerCase(Locale.ROOT).startsWith(lower)) {
                result.add(option);
            }
        }
        return result;
    }
}
