package fr.legendaryclasses.command;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.classes.ClassType;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.experience.ExperienceManager;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import fr.legendaryclasses.util.MessageManager;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

/** Gère /classes (menu) et /classe (sous-commandes). */
public final class ClassCommand implements CommandExecutor, TabCompleter {

    private final LegendaryClassesPlugin plugin;
    private final AdminCommand adminCommand;

    public ClassCommand(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
        this.adminCommand = new AdminCommand(plugin);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("classes")) {
            if (sender instanceof Player player) {
                plugin.getMenuManager().openClassMenu(player);
            } else {
                showClassList(sender);
            }
            return true;
        }
        if (args.length == 0) {
            handleCurrent(sender);
            return true;
        }
        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "choisir", "choose" -> handleChoose(sender, args);
            case "info" -> handleInfo(sender);
            case "competences", "compétences", "skills" -> handleSkills(sender);
            case "stats" -> handleStats(sender);
            case "reset" -> handleReset(sender, args);
            case "cast", "lancer" -> handleCast(sender, args);
            case "cooldown", "cd", "recharge" -> handleCooldown(sender, args);
            case "item", "objet" -> handleItem(sender, args);
            case "menu" -> handleMenu(sender);
            case "admin" -> adminCommand.execute(sender, Arrays.copyOfRange(args, 1, args.length));
            case "help", "aide" -> {
                messages().sendList(sender, "usage.help");
                messages().sendList(sender, "skill.help-extra");
            }
            default -> messages().send(sender, "general.unknown-subcommand");
        }
        return true;
    }

    // ---------- /classes (console) ----------

    private void showClassList(CommandSender sender) {
        ClassManager classManager = plugin.getClassManager();
        messages().sendLine(sender, messages().raw("classes-list.header"));
        for (ClassType type : ClassType.values()) {
            messages().sendLine(sender, messages().raw("classes-list.line",
                    "class", classManager.getDisplayName(type),
                    "specialty", classManager.getSpecialty(type)));
        }
        messages().sendLine(sender, messages().raw("classes-list.footer"));
    }

    // ---------- /classe ----------

    private void handleCurrent(CommandSender sender) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        if (data.getClassType() == null) {
            messages().send(player, "class.none");
            return;
        }
        messages().send(player, "class.current",
                "class", plugin.getClassManager().getDisplayName(data.getClassType()),
                "level", data.getLevel());
    }

    private void handleChoose(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        if (args.length < 2) {
            messages().send(player, "usage.choose", "classes", String.join(", ", ClassType.ids()));
            return;
        }
        Optional<ClassType> type = ClassType.fromInput(args[1]);
        if (type.isEmpty()) {
            messages().send(player, "class.unknown", "input", args[1]);
            return;
        }
        if (plugin.getClassManager().chooseClass(player, data, type.get()) == ClassManager.ChooseResult.ALREADY_HAS_CLASS) {
            messages().send(player, "class.already");
        }
    }

    private void handleInfo(CommandSender sender) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        ClassType type = data.getClassType();
        if (type == null) {
            messages().send(player, "class.none");
            return;
        }
        ClassManager classManager = plugin.getClassManager();
        messages().sendLine(player, messages().raw("info.header", "class", classManager.getDisplayName(type)));
        messages().sendLine(player, messages().raw("info.specialty", "specialty", classManager.getSpecialty(type)));
        for (String line : classManager.getDescription(type)) {
            messages().sendLine(player, line);
        }
        messages().sendLine(player, messages().raw("info.skills-title"));
        for (SkillType skill : SkillType.forClass(type)) {
            int unlockLevel = classManager.getUnlockLevel(skill);
            if (classManager.isUnlocked(data, skill)) {
                messages().sendLine(player, messages().raw("info.skill-unlocked",
                        "skill", classManager.getSkillName(skill),
                        "level", unlockLevel,
                        "description", classManager.getSkillDescription(skill)));
            } else {
                messages().sendLine(player, messages().raw("info.skill-locked",
                        "skill", classManager.getSkillName(skill),
                        "level", unlockLevel));
            }
        }
    }

    private void handleSkills(CommandSender sender) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        ClassType type = data.getClassType();
        if (type == null) {
            messages().send(player, "class.none");
            return;
        }
        ClassManager classManager = plugin.getClassManager();
        messages().sendLine(player, messages().raw("skill-list.header"));
        List<SkillType> unlocked = classManager.getUnlockedSkills(data);
        if (unlocked.isEmpty()) {
            messages().sendLine(player, messages().raw("skill-list.none"));
        }
        for (SkillType skill : unlocked) {
            messages().sendLine(player, messages().raw("skill-list.line",
                    "skill", classManager.getSkillName(skill),
                    "level", classManager.getUnlockLevel(skill),
                    "description", classManager.getSkillDescription(skill)));
        }
        SkillType next = null;
        for (SkillType skill : SkillType.forClass(type)) {
            if (!classManager.isUnlocked(data, skill)
                    && (next == null || classManager.getUnlockLevel(skill) < classManager.getUnlockLevel(next))) {
                next = skill;
            }
        }
        if (next != null) {
            messages().sendLine(player, messages().raw("skill-list.next",
                    "skill", classManager.getSkillName(next),
                    "level", classManager.getUnlockLevel(next)));
        }
    }

    private void handleStats(CommandSender sender) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        if (data.getClassType() == null) {
            messages().send(player, "class.none");
            return;
        }
        ExperienceManager experience = plugin.getExperienceManager();
        boolean maxed = data.getLevel() >= experience.getMaxLevel();
        double ratio = experience.getProgressRatio(data);
        messages().sendList(player, "stats",
                "class", plugin.getClassManager().getDisplayName(data.getClassType()),
                "level", data.getLevel(),
                "max", experience.getMaxLevel(),
                "xp", maxed ? messages().raw("level.max-label") : String.valueOf(data.getXp()),
                "needed", maxed ? messages().raw("level.max-label") : String.valueOf(experience.getXpForNextLevel(data.getLevel())),
                "percent", (int) Math.round(ratio * 100),
                "bar", experience.buildBar(ratio, 20));
    }

    private void handleReset(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        if (data.getClassType() == null) {
            messages().send(player, "class.none");
            return;
        }
        ClassManager classManager = plugin.getClassManager();
        boolean confirm = args.length >= 2
                && (args[1].equalsIgnoreCase("confirm") || args[1].equalsIgnoreCase("confirmer"));
        if (confirm && classManager.confirmReset(player.getUniqueId())) {
            classManager.resetPlayer(player, data);
            messages().send(player, "class.reset-done");
            return;
        }
        classManager.requestReset(player.getUniqueId());
        messages().send(player, "class.reset-prompt",
                "seconds", plugin.getConfig().getLong("classes.reset-confirm-seconds", 15L));
    }

    // ---------- Compétences ----------

    private void handleCast(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        if (!plugin.getConfig().getBoolean("skill-settings.allow-command-cast", true)) {
            messages().send(player, "skill.command-cast-disabled");
            return;
        }
        if (args.length < 2) {
            messages().send(player, "skill.usage-cast");
            return;
        }
        Optional<SkillType> skill = resolveSkill(args[1]);
        if (skill.isEmpty()) {
            messages().send(player, "skill.unknown", "input", args[1]);
            return;
        }
        plugin.getSkillManager().cast(player, skill.get());
    }

    private void handleItem(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        if (args.length < 2) {
            messages().send(player, "skill.usage-item");
            return;
        }
        Optional<SkillType> skill = resolveSkill(args[1]);
        if (skill.isEmpty()) {
            messages().send(player, "skill.unknown", "input", args[1]);
            return;
        }
        plugin.getSkillManager().getItems().requestItem(player, skill.get());
    }

    private void handleCooldown(CommandSender sender, String[] args) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        PlayerData data = requireData(player);
        if (data == null) return;
        if (data.getClassType() == null) {
            messages().send(player, "class.none");
            return;
        }
        ClassManager classManager = plugin.getClassManager();
        if (args.length >= 2) {
            Optional<SkillType> skill = resolveSkill(args[1]);
            if (skill.isEmpty()) {
                messages().send(player, "skill.unknown", "input", args[1]);
                return;
            }
            sendCooldownLine(player, skill.get());
            return;
        }
        messages().sendLine(player, messages().raw("cooldown.header"));
        List<SkillType> unlocked = classManager.getUnlockedSkills(data);
        if (unlocked.isEmpty()) {
            messages().sendLine(player, messages().raw("skill-list.none"));
        }
        for (SkillType skill : unlocked) {
            sendCooldownLine(player, skill);
        }
    }

    private void sendCooldownLine(Player player, SkillType skill) {
        long remaining = plugin.getSkillManager().getCooldowns().getRemainingMillis(player.getUniqueId(), skill);
        String name = plugin.getClassManager().getSkillName(skill);
        if (remaining <= 0L) {
            messages().sendLine(player, messages().raw("cooldown.line-ready", "skill", name));
        } else {
            messages().sendLine(player, messages().raw("cooldown.line-wait",
                    "skill", name, "time", SkillManager.formatSeconds(remaining)));
        }
    }

    private void handleMenu(CommandSender sender) {
        Player player = requirePlayer(sender);
        if (player == null) return;
        plugin.getMenuManager().openSkillMenu(player);
    }

    private Optional<SkillType> resolveSkill(String input) {
        return SkillType.fromId(input.toLowerCase(Locale.ROOT).replace('-', '_'));
    }

    // ---------- Aides ----------

    private Player requirePlayer(CommandSender sender) {
        if (sender instanceof Player player) {
            return player;
        }
        messages().send(sender, "general.players-only");
        return null;
    }

    private PlayerData requireData(Player player) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            messages().send(player, "general.data-not-loaded");
        }
        return data;
    }

    private MessageManager messages() {
        return plugin.getMessageManager();
    }

    // ---------- Complétion ----------

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (!command.getName().equalsIgnoreCase("classe")) {
            return Collections.emptyList();
        }
        if (args.length == 1) {
            List<String> subs = new ArrayList<>(List.of("choisir", "info", "competences", "stats",
                    "reset", "cast", "cooldown", "item", "menu", "help"));
            if (adminCommand.hasAnyPermission(sender)) {
                subs.add("admin");
            }
            return AdminCommand.filter(subs, args[0]);
        }
        String sub = args[0].toLowerCase(Locale.ROOT);
        if (args.length == 2 && (sub.equals("choisir") || sub.equals("choose"))) {
            return AdminCommand.filter(ClassType.ids(), args[1]);
        }
        if (args.length == 2 && sub.equals("reset")) {
            return AdminCommand.filter(List.of("confirm"), args[1]);
        }
        if (args.length == 2 && List.of("cast", "lancer", "cooldown", "cd", "recharge", "item", "objet").contains(sub)
                && sender instanceof Player player) {
            PlayerData data = plugin.getDataManager().get(player);
            List<String> ids = new ArrayList<>();
            if (data != null) {
                for (SkillType skill : plugin.getClassManager().getUnlockedSkills(data)) {
                    ids.add(skill.getId());
                }
            }
            return AdminCommand.filter(ids, args[1]);
        }
        if (sub.equals("admin")) {
            return adminCommand.tabComplete(sender, Arrays.copyOfRange(args, 1, args.length));
        }
        return Collections.emptyList();
    }
}
