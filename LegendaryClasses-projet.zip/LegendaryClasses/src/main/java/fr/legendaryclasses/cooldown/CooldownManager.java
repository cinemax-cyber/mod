package fr.legendaryclasses.cooldown;

import fr.legendaryclasses.skill.SkillType;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Temps de recharge en mémoire (thread principal uniquement). Conservés après déconnexion pour éviter l'abus. */
public final class CooldownManager {

    private final Map<UUID, Map<SkillType, Long>> cooldowns = new HashMap<>();

    public long getRemainingMillis(UUID uuid, SkillType skill) {
        Map<SkillType, Long> map = cooldowns.get(uuid);
        if (map == null) {
            return 0L;
        }
        Long expiry = map.get(skill);
        if (expiry == null) {
            return 0L;
        }
        long remaining = expiry - System.currentTimeMillis();
        if (remaining <= 0L) {
            map.remove(skill);
            return 0L;
        }
        return remaining;
    }

    public void start(UUID uuid, SkillType skill, long durationMillis) {
        if (durationMillis <= 0L) {
            return;
        }
        cooldowns.computeIfAbsent(uuid, key -> new EnumMap<>(SkillType.class))
                .put(skill, System.currentTimeMillis() + durationMillis);
    }

    /** Supprime les entrées expirées d'un joueur (appelé à la déconnexion : pas de fuite mémoire). */
    public void purgeExpired(UUID uuid) {
        Map<SkillType, Long> map = cooldowns.get(uuid);
        if (map == null) {
            return;
        }
        long now = System.currentTimeMillis();
        map.values().removeIf(expiry -> expiry <= now);
        if (map.isEmpty()) {
            cooldowns.remove(uuid);
        }
    }

    public void clear(UUID uuid) {
        cooldowns.remove(uuid);
    }
}
