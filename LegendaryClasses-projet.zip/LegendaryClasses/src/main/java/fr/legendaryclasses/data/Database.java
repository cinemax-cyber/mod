package fr.legendaryclasses.data;

import java.io.File;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.util.Collection;
import java.util.Optional;
import java.util.UUID;
import java.util.logging.Logger;

/** Accès SQLite (driver fourni par Paper). Toutes les méthodes sont sérialisées. */
public final class Database {

    private static final String UPSERT =
            "INSERT INTO players (uuid, name, class, level, xp, updated_at) VALUES (?, ?, ?, ?, ?, ?) "
                    + "ON CONFLICT(uuid) DO UPDATE SET name = excluded.name, class = excluded.class, "
                    + "level = excluded.level, xp = excluded.xp, updated_at = excluded.updated_at";

    private final File file;
    private final Logger logger;
    private Connection connection;

    public Database(File file, Logger logger) {
        this.file = file;
        this.logger = logger;
    }

    public synchronized void open() throws SQLException {
        try {
            Class.forName("org.sqlite.JDBC");
        } catch (ClassNotFoundException ex) {
            throw new SQLException("Driver SQLite introuvable sur ce serveur.", ex);
        }
        File parent = file.getParentFile();
        if (parent != null && !parent.exists() && !parent.mkdirs()) {
            throw new SQLException("Impossible de créer le dossier de données.");
        }
        connection = DriverManager.getConnection("jdbc:sqlite:" + file.getAbsolutePath());
        try (Statement statement = connection.createStatement()) {
            statement.execute("PRAGMA journal_mode=WAL");
            statement.execute("PRAGMA synchronous=NORMAL");
            statement.execute("CREATE TABLE IF NOT EXISTS players ("
                    + "uuid TEXT PRIMARY KEY NOT NULL, "
                    + "name TEXT NOT NULL, "
                    + "class TEXT, "
                    + "level INTEGER NOT NULL DEFAULT 1, "
                    + "xp INTEGER NOT NULL DEFAULT 0, "
                    + "updated_at INTEGER NOT NULL DEFAULT 0)");
        }
    }

    public synchronized Optional<PlayerData.Snapshot> load(UUID uuid) throws SQLException {
        ensureOpen();
        try (PreparedStatement statement = connection.prepareStatement(
                "SELECT name, class, level, xp FROM players WHERE uuid = ?")) {
            statement.setString(1, uuid.toString());
            try (ResultSet rs = statement.executeQuery()) {
                if (!rs.next()) {
                    return Optional.empty();
                }
                return Optional.of(new PlayerData.Snapshot(
                        uuid, rs.getString("name"), rs.getString("class"), rs.getInt("level"), rs.getLong("xp")));
            }
        }
    }

    public synchronized void save(PlayerData.Snapshot snapshot) throws SQLException {
        ensureOpen();
        try (PreparedStatement statement = connection.prepareStatement(UPSERT)) {
            bind(statement, snapshot);
            statement.executeUpdate();
        }
    }

    public synchronized void saveBatch(Collection<PlayerData.Snapshot> snapshots) throws SQLException {
        if (snapshots.isEmpty()) {
            return;
        }
        ensureOpen();
        boolean previousAutoCommit = connection.getAutoCommit();
        connection.setAutoCommit(false);
        try (PreparedStatement statement = connection.prepareStatement(UPSERT)) {
            for (PlayerData.Snapshot snapshot : snapshots) {
                bind(statement, snapshot);
                statement.addBatch();
            }
            statement.executeBatch();
            connection.commit();
        } catch (SQLException ex) {
            connection.rollback();
            throw ex;
        } finally {
            connection.setAutoCommit(previousAutoCommit);
        }
    }

    public synchronized void close() {
        if (connection == null) {
            return;
        }
        try {
            connection.close();
        } catch (SQLException ex) {
            logger.warning("Erreur à la fermeture de la base : " + ex.getMessage());
        } finally {
            connection = null;
        }
    }

    private void ensureOpen() throws SQLException {
        if (connection == null || connection.isClosed()) {
            throw new SQLException("La base de données n'est pas ouverte.");
        }
    }

    private static void bind(PreparedStatement statement, PlayerData.Snapshot s) throws SQLException {
        statement.setString(1, s.uuid().toString());
        statement.setString(2, s.name() == null ? "" : s.name());
        if (s.classId() == null) {
            statement.setNull(3, Types.VARCHAR);
        } else {
            statement.setString(3, s.classId());
        }
        statement.setInt(4, s.level());
        statement.setLong(5, s.xp());
        statement.setLong(6, System.currentTimeMillis());
    }
}
