package fr.legendaryclasses.data;

import fr.legendaryclasses.classes.ClassType;

import java.util.Objects;
import java.util.UUID;

/** État RPG d'un joueur, conservé en mémoire pendant sa connexion. Utilisé depuis le thread principal. */
public final class PlayerData {

    /** Copie immuable destinée à l'écriture en base (thread séparé). */
    public record Snapshot(UUID uuid, String name, String classId, int level, long xp) { }

    private final UUID uuid;
    private final long loadedAtMillis = System.currentTimeMillis();
    private String name;
    private ClassType classType;
    private int level;
    private long xp;
    private volatile boolean dirty;
    private volatile long lastActivityMillis = System.currentTimeMillis();

    public PlayerData(UUID uuid, String name) {
        this(uuid, name, null, 1, 0L);
    }

    public PlayerData(UUID uuid, String name, ClassType classType, int level, long xp) {
        this.uuid = uuid;
        this.name = name;
        this.classType = classType;
        this.level = level;
        this.xp = xp;
    }

    public UUID getUuid() { return uuid; }

    public String getName() { return name; }

    public void setName(String name) {
        if (!Objects.equals(this.name, name)) {
            this.name = name;
            this.dirty = true;
        }
    }

    public ClassType getClassType() { return classType; }

    public void setClassType(ClassType classType) {
        this.classType = classType;
        this.dirty = true;
    }

    public int getLevel() { return level; }

    public void setLevel(int level) {
        this.level = level;
        this.dirty = true;
    }

    public long getXp() { return xp; }

    public void setXp(long xp) {
        this.xp = xp;
        this.dirty = true;
    }

    public boolean isDirty() { return dirty; }

    public void markDirty() { this.dirty = true; }

    public void markClean() { this.dirty = false; }

    public long getLoadedAtMillis() { return loadedAtMillis; }

    public long getLastActivityMillis() { return lastActivityMillis; }

    /** Appelé quand le joueur manipule sa caméra (détection d'inactivité). */
    public void touchActivity() { this.lastActivityMillis = System.currentTimeMillis(); }

    /** Réinitialise classe, niveau et expérience. */
    public void reset() {
        this.classType = null;
        this.level = 1;
        this.xp = 0L;
        this.dirty = true;
    }

    public Snapshot snapshot() {
        return new Snapshot(uuid, name, classType == null ? null : classType.getId(), level, xp);
    }
}
