package fr.legendaryclasses.data;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassType;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;

import java.io.File;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/** Cache des joueurs + persistance asynchrone (file mono-thread : l'ordre des opérations est garanti). */
public final class PlayerDataManager {

    private static final long STALE_ENTRY_MILLIS = 120_000L;

    private final LegendaryClassesPlugin plugin;
    private final Database database;
    private final ExecutorService executor;
    private final Map<UUID, PlayerData> cache = new ConcurrentHashMap<>();
    private BukkitTask autosaveTask;

    public PlayerDataManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
        this.database = new Database(new File(plugin.getDataFolder(), "players.db"), plugin.getLogger());
        this.executor = Executors.newSingleThreadExecutor(runnable -> {
            Thread thread = new Thread(runnable, "LegendaryClasses-Database");
            thread.setDaemon(true);
            return thread;
        });
    }

    public boolean init() {
        try {
            database.open();
            return true;
        } catch (SQLException ex) {
            plugin.getLogger().log(Level.SEVERE, "Erreur d'ouverture de la base SQLite", ex);
            return false;
        }
    }

    public void startAutosave() {
        long minutes = Math.max(1, plugin.getConfig().getLong("storage.autosave-minutes", 5));
        long ticks = minutes * 60L * 20L;
        autosaveTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            saveDirty();
            cleanupStale();
        }, ticks, ticks);
    }

    /** Données en cache d'un joueur connecté, ou null si non chargées. */
    public PlayerData get(Player player) {
        return cache.get(player.getUniqueId());
    }

    public PlayerData get(UUID uuid) {
        return cache.get(uuid);
    }

    /**
     * Charge (ou crée) les données d'un joueur en attendant la fin de la lecture.
     * Retourne null si la lecture a échoué : on évite ainsi d'écraser une sauvegarde existante.
     */
    public PlayerData loadBlocking(UUID uuid, String name) {
        PlayerData existing = cache.get(uuid);
        if (existing != null) {
            return existing;
        }
        try {
            PlayerData data = CompletableFuture.supplyAsync(() -> {
                try {
                    Optional<PlayerData.Snapshot> snapshot = database.load(uuid);
                    return snapshot.map(s -> fromSnapshot(s, name)).orElseGet(() -> new PlayerData(uuid, name));
                } catch (SQLException ex) {
                    throw new IllegalStateException(ex);
                }
            }, executor).join();
            cache.put(uuid, data);
            return data;
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "Échec du chargement des données de " + name, ex);
            return null;
        }
    }

    /** Retire un joueur du cache et sauvegarde ses données de façon asynchrone. */
    public void unload(UUID uuid) {
        PlayerData data = cache.remove(uuid);
        if (data == null) {
            return;
        }
        PlayerData.Snapshot snapshot = data.snapshot();
        data.markClean();
        try {
            executor.execute(() -> {
                try {
                    database.save(snapshot);
                } catch (SQLException ex) {
                    plugin.getLogger().log(Level.SEVERE, "Sauvegarde impossible pour " + snapshot, ex);
                }
            });
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "File de sauvegarde indisponible pour " + snapshot, ex);
        }
    }

    /** Sauvegarde (asynchrone) tous les joueurs dont les données ont changé. */
    public void saveDirty() {
        List<PlayerData.Snapshot> batch = new ArrayList<>();
        for (PlayerData data : cache.values()) {
            if (data.isDirty()) {
                batch.add(data.snapshot());
                data.markClean();
            }
        }
        if (batch.isEmpty()) {
            return;
        }
        try {
            executor.execute(() -> {
                try {
                    database.saveBatch(batch);
                } catch (SQLException ex) {
                    plugin.getLogger().log(Level.SEVERE, "Échec de la sauvegarde automatique", ex);
                    for (PlayerData.Snapshot snapshot : batch) {
                        PlayerData data = cache.get(snapshot.uuid());
                        if (data != null) {
                            data.markDirty();
                        }
                    }
                }
            });
        } catch (RuntimeException ex) {
            plugin.getLogger().log(Level.SEVERE, "File de sauvegarde indisponible", ex);
        }
    }

    /** Sauvegarde finale synchrone à l'arrêt du plugin. */
    public void shutdown() {
        if (autosaveTask != null) {
            autosaveTask.cancel();
        }
        List<PlayerData.Snapshot> all = new ArrayList<>();
        for (PlayerData data : cache.values()) {
            all.add(data.snapshot());
        }
        cache.clear();
        if (!all.isEmpty()) {
            try {
                executor.execute(() -> {
                    try {
                        database.saveBatch(all);
                    } catch (SQLException ex) {
                        plugin.getLogger().log(Level.SEVERE, "Échec de la sauvegarde finale", ex);
                    }
                });
            } catch (RuntimeException ex) {
                plugin.getLogger().log(Level.SEVERE, "Sauvegarde finale impossible", ex);
            }
        }
        executor.shutdown();
        try {
            if (!executor.awaitTermination(15, TimeUnit.SECONDS)) {
                plugin.getLogger().warning("La sauvegarde finale n'a pas terminé dans les temps.");
            }
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
        }
        database.close();
    }

    /** Évite les fuites mémoire si une connexion a été refusée après le chargement des données. */
    private void cleanupStale() {
        long now = System.currentTimeMillis();
        for (Map.Entry<UUID, PlayerData> entry : cache.entrySet()) {
            if (Bukkit.getPlayer(entry.getKey()) == null
                    && now - entry.getValue().getLoadedAtMillis() > STALE_ENTRY_MILLIS) {
                unload(entry.getKey());
            }
        }
    }

    private PlayerData fromSnapshot(PlayerData.Snapshot snapshot, String name) {
        int maxLevel = Math.max(1, plugin.getConfig().getInt("levels.max-level", 50));
        ClassType type = snapshot.classId() == null ? null : ClassType.fromInput(snapshot.classId()).orElse(null);
        int level = Math.max(1, Math.min(maxLevel, snapshot.level()));
        long xp = type == null ? 0L : Math.max(0L, snapshot.xp());
        return new PlayerData(snapshot.uuid(), name, type, level, xp);
    }
}
