package fr.legendaryclasses.experience;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.data.PlayerData;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.CreatureSpawnEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.persistence.PersistentDataType;

public final class ExperienceListener implements Listener {

    private final LegendaryClassesPlugin plugin;
    private final NamespacedKey noXpKey;

    public ExperienceListener(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
        this.noXpKey = new NamespacedKey(plugin, "no_xp");
    }

    /** Marque (de façon persistante) les mobs issus de sources interdites : ils ne donneront jamais d'XP. */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onSpawn(CreatureSpawnEvent event) {
        if (plugin.getExperienceManager().isDeniedSpawnReason(event.getSpawnReason())) {
            event.getEntity().getPersistentDataContainer().set(noXpKey, PersistentDataType.BYTE, (byte) 1);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player) {
            return;
        }
        Player killer = entity.getKiller();
        if (killer == null) {
            return;
        }
        PlayerData data = plugin.getDataManager().get(killer);
        if (data == null || data.getClassType() == null) {
            return;
        }
        ExperienceManager experience = plugin.getExperienceManager();
        if (experience.isWorldDisabled(entity.getWorld().getName())) {
            return;
        }
        if (entity.getPersistentDataContainer().has(noXpKey, PersistentDataType.BYTE)) {
            return;
        }
        double baseXp = experience.getMobXp(entity);
        if (baseXp <= 0) {
            return;
        }
        if (experience.isAfk(data)) {
            return;
        }
        double multiplier = experience.registerKill(killer.getUniqueId());
        long amount = Math.round(baseXp * multiplier * experience.getGlobalMultiplier());
        if (amount <= 0) {
            return;
        }
        experience.addExperience(killer, data, amount, true);
    }

    /** Une rotation de caméra prouve que le joueur est actif (détection des fermes AFK). */
    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onMove(PlayerMoveEvent event) {
        if (!event.hasChangedOrientation()) {
            return;
        }
        PlayerData data = plugin.getDataManager().get(event.getPlayer());
        if (data != null) {
            data.touchActivity();
        }
    }
}
