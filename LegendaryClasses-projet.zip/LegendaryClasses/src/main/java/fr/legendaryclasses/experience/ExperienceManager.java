package fr.legendaryclasses.experience;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.skill.SkillType;
import fr.legendaryclasses.util.MessageManager;
import fr.legendaryclasses.util.SoundUtil;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.CreatureSpawnEvent.SpawnReason;

import java.time.Duration;
import java.util.ArrayDeque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class ExperienceManager {

    private final LegendaryClassesPlugin plugin;
    private final Map<String, Double> mobXp = new HashMap<>();
    private final Set<SpawnReason> deniedSpawnReasons = EnumSet.noneOf(SpawnReason.class);
    private final Set<String> disabledWorlds = new HashSet<>();
    private final Map<UUID, ArrayDeque<Long>> recentKills = new HashMap<>();

    private int maxLevel = 50;
    private double base = 100;
    private double flat = 20;
    private double curve = 8;
    private double exponent = 1.7;
    private double globalMultiplier = 1.0;
    private double defaultHostileXp = 4;
    private boolean showActionBar = true;
    private int afkSeconds = 120;
    private int killWindowSeconds = 60;
    private int maxKillsPerWindow = 25;
    private double reducedMultiplier = 0.25;

    public ExperienceManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        FileConfiguration config = plugin.getConfig();
        maxLevel = Math.max(1, config.getInt("levels.max-level", 50));
        base = config.getDouble("levels.formula.base", 100);
        flat = config.getDouble("levels.formula.flat-per-level", 20);
        curve = config.getDouble("levels.formula.curve", 8);
        exponent = config.getDouble("levels.formula.exponent", 1.7);

        globalMultiplier = Math.max(0, config.getDouble("experience.global-multiplier", 1.0));
        defaultHostileXp = Math.max(0, config.getDouble("experience.default-hostile-xp", 4));
        showActionBar = config.getBoolean("experience.show-action-bar", true);

        disabledWorlds.clear();
        for (String world : config.getStringList("experience.disabled-worlds")) {
            disabledWorlds.add(world.toLowerCase(Locale.ROOT));
        }

        mobXp.clear();
        ConfigurationSection section = config.getConfigurationSection("experience.mob-xp");
        if (section != null) {
            for (String key : section.getKeys(false)) {
                mobXp.put(key.toLowerCase(Locale.ROOT), Math.max(0, section.getDouble(key)));
            }
        }

        deniedSpawnReasons.clear();
        for (String name : config.getStringList("experience.anti-abuse.denied-spawn-reasons")) {
            try {
                deniedSpawnReasons.add(SpawnReason.valueOf(name.trim().toUpperCase(Locale.ROOT)));
            } catch (IllegalArgumentException ex) {
                plugin.getLogger().warning("Raison d'apparition inconnue dans config.yml : " + name);
            }
        }

        afkSeconds = Math.max(0, config.getInt("experience.anti-abuse.afk-seconds", 120));
        killWindowSeconds = Math.max(1, config.getInt("experience.anti-abuse.kill-window-seconds", 60));
        maxKillsPerWindow = Math.max(1, config.getInt("experience.anti-abuse.max-kills-per-window", 25));
        reducedMultiplier = Math.max(0, config.getDouble("experience.anti-abuse.reduced-multiplier", 0.25));
    }

    // ---------- Formule ----------

    public int getMaxLevel() {
        return maxLevel;
    }

    /** XP nécessaire pour passer du niveau donné au suivant (0 au niveau maximum). */
    public long getXpForNextLevel(int level) {
        if (level >= maxLevel) {
            return 0L;
        }
        int steps = Math.max(0, level - 1);
        double value = base + flat * steps + curve * Math.pow(steps, exponent);
        return Math.max(1L, Math.round(value));
    }

    public double getProgressRatio(PlayerData data) {
        if (data.getLevel() >= maxLevel) {
            return 1.0;
        }
        long needed = getXpForNextLevel(data.getLevel());
        return Math.max(0.0, Math.min(1.0, (double) data.getXp() / needed));
    }

    public String buildBar(double ratio, int length) {
        int filled = (int) Math.round(Math.max(0.0, Math.min(1.0, ratio)) * length);
        StringBuilder bar = new StringBuilder("&a");
        for (int i = 0; i < length; i++) {
            if (i == filled) {
                bar.append("&7");
            }
            bar.append('|');
        }
        return bar.toString();
    }

    // ---------- Gain d'expérience ----------

    public void addExperience(Player player, PlayerData data, long amount, boolean notify) {
        if (amount <= 0 || data.getClassType() == null || data.getLevel() >= maxLevel) {
            return;
        }
        int oldLevel = data.getLevel();
        data.setXp(data.getXp() + amount);
        while (data.getLevel() < maxLevel) {
            long needed = getXpForNextLevel(data.getLevel());
            if (data.getXp() < needed) {
                break;
            }
            data.setXp(data.getXp() - needed);
            data.setLevel(data.getLevel() + 1);
        }
        if (data.getLevel() >= maxLevel) {
            data.setXp(0L);
        }
        if (data.getLevel() > oldLevel) {
            announceLevelUp(player, data, oldLevel);
        }
        if (notify && showActionBar) {
            sendXpActionBar(player, data, amount);
        }
    }

    public void setLevel(Player player, PlayerData data, int newLevel) {
        int clamped = Math.max(1, Math.min(maxLevel, newLevel));
        int oldLevel = data.getLevel();
        data.setLevel(clamped);
        data.setXp(0L);
        if (clamped > oldLevel) {
            announceLevelUp(player, data, oldLevel);
        }
    }

    private void announceLevelUp(Player player, PlayerData data, int oldLevel) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();

        Component title = messages.component("level.up-title", "level", data.getLevel());
        Component subtitle = messages.component("level.up-subtitle", "class", classManager.getDisplayName(data.getClassType()));
        player.showTitle(Title.title(title, subtitle,
                Title.Times.times(Duration.ofMillis(300), Duration.ofSeconds(2), Duration.ofMillis(500))));
        messages.send(player, "level.up-chat", "level", data.getLevel());
        SoundUtil.play(player, plugin.getConfig().getString("sounds.level-up"), 1f, 1f);

        boolean unlocked = false;
        for (SkillType skill : SkillType.forClass(data.getClassType())) {
            int unlockLevel = classManager.getUnlockLevel(skill);
            if (unlockLevel > oldLevel && unlockLevel <= data.getLevel()) {
                messages.send(player, "level.skill-unlocked", "skill", classManager.getSkillName(skill));
                unlocked = true;
            }
        }
        if (unlocked) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.skill-unlock"), 1f, 1.3f);
        }
    }

    private void sendXpActionBar(Player player, PlayerData data, long amount) {
        MessageManager messages = plugin.getMessageManager();
        String needed = data.getLevel() >= maxLevel
                ? messages.raw("level.max-label")
                : String.valueOf(getXpForNextLevel(data.getLevel()));
        player.sendActionBar(messages.component("level.xp-actionbar",
                "amount", amount, "xp", data.getXp(), "needed", needed));
    }

    // ---------- Règles de gain (utilisées par ExperienceListener) ----------

    public double getMobXp(LivingEntity entity) {
        Double configured = mobXp.get(entity.getType().getKey().getKey());
        if (configured != null) {
            return configured;
        }
        return entity instanceof Enemy ? defaultHostileXp : 0.0;
    }

    public double getGlobalMultiplier() {
        return globalMultiplier;
    }

    public boolean isWorldDisabled(String worldName) {
        return disabledWorlds.contains(worldName.toLowerCase(Locale.ROOT));
    }

    public boolean isDeniedSpawnReason(SpawnReason reason) {
        return deniedSpawnReasons.contains(reason);
    }

    public boolean isAfk(PlayerData data) {
        return afkSeconds > 0 && System.currentTimeMillis() - data.getLastActivityMillis() > afkSeconds * 1000L;
    }

    /** Enregistre un kill et retourne le multiplicateur anti-farm à appliquer (1.0 ou réduit). */
    public double registerKill(UUID uuid) {
        long now = System.currentTimeMillis();
        long cutoff = now - killWindowSeconds * 1000L;
        ArrayDeque<Long> kills = recentKills.computeIfAbsent(uuid, key -> new ArrayDeque<>());
        while (!kills.isEmpty() && kills.peekFirst() < cutoff) {
            kills.pollFirst();
        }
        kills.addLast(now);
        return kills.size() > maxKillsPerWindow ? reducedMultiplier : 1.0;
    }

    public void forget(UUID uuid) {
        recentKills.remove(uuid);
    }
}
