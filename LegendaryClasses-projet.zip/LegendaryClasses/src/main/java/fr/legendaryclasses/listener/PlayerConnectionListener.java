package fr.legendaryclasses.listener;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.data.PlayerData;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.AsyncPlayerPreLoginEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.UUID;

public final class PlayerConnectionListener implements Listener {

    private final LegendaryClassesPlugin plugin;

    public PlayerConnectionListener(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    /** Chargement hors du thread principal pendant la phase de connexion. */
    @EventHandler(priority = EventPriority.MONITOR)
    public void onPreLogin(AsyncPlayerPreLoginEvent event) {
        if (event.getLoginResult() != AsyncPlayerPreLoginEvent.Result.ALLOWED) {
            return;
        }
        PlayerData data = plugin.getDataManager().loadBlocking(event.getUniqueId(), event.getName());
        if (data == null) {
            event.disallow(AsyncPlayerPreLoginEvent.Result.KICK_OTHER,
                    plugin.getMessageManager().component("general.data-load-failed"));
        }
    }

    @EventHandler(priority = EventPriority.NORMAL)
    public void onJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            // Cas rare (double connexion, /reload) : chargement de secours
            data = plugin.getDataManager().loadBlocking(player.getUniqueId(), player.getName());
        }
        if (data == null) {
            player.kick(plugin.getMessageManager().component("general.data-load-failed"));
            return;
        }
        data.setName(player.getName());
        data.touchActivity();

        if (data.getClassType() == null) {
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline()) {
                    plugin.getMessageManager().send(player, "class.welcome");
                }
            }, 40L);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        plugin.getExperienceManager().forget(uuid);
        plugin.getClassManager().clearPending(uuid);
        plugin.getDataManager().unload(uuid);
    }
}
