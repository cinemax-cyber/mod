package fr.legendaryclasses.listener;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

import java.util.Optional;

public final class SkillListener implements Listener {

    private final LegendaryClassesPlugin plugin;

    public SkillListener(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    private SkillManager manager() {
        return plugin.getSkillManager();
    }

    private boolean isSkillItem(ItemStack item) {
        return item != null && !item.getType().isAir() && manager().getItems().getSkill(item).isPresent();
    }

    // ---------- Utilisation ----------

    @EventHandler(priority = EventPriority.HIGH)
    public void onInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) {
            return; // évite le double déclenchement main principale / secondaire
        }
        Action action = event.getAction();
        if (action != Action.RIGHT_CLICK_AIR && action != Action.RIGHT_CLICK_BLOCK) {
            return;
        }
        ItemStack item = event.getItem();
        Optional<SkillType> skill = manager().getItems().getSkill(item);
        if (skill.isEmpty()) {
            return;
        }
        Player player = event.getPlayer();
        // On ne gêne pas les interactions normales avec les blocs (coffres, portes, etc.)
        if (action == Action.RIGHT_CLICK_BLOCK && event.getClickedBlock() != null
                && event.getClickedBlock().getType().isInteractable() && !player.isSneaking()) {
            return;
        }
        event.setCancelled(true);
        if (!manager().getItems().isOwner(item, player.getUniqueId())) {
            plugin.getMessageManager().send(player, "skill.item-not-yours");
            return;
        }
        manager().cast(player, skill.get());
    }

    // ---------- Protection des objets ----------

    @EventHandler(ignoreCancelled = true)
    public void onDrop(PlayerDropItemEvent event) {
        if (plugin.getConfig().getBoolean("skill-items.prevent-drop", true)
                && isSkillItem(event.getItemDrop().getItemStack())) {
            event.setCancelled(true);
            plugin.getMessageManager().send(event.getPlayer(), "skill.item-no-drop");
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDeath(PlayerDeathEvent event) {
        event.getDrops().removeIf(this::isSkillItem);
        manager().breakStealth(event.getEntity());
    }

    @EventHandler(ignoreCancelled = true)
    public void onFrame(PlayerInteractEntityEvent event) {
        if (event.getRightClicked() instanceof ItemFrame
                && isSkillItem(event.getPlayer().getInventory().getItem(event.getHand()))) {
            event.setCancelled(true);
        }
    }

    /** Empêche de ranger un objet de compétence dans un coffre, un établi, etc. */
    @EventHandler(ignoreCancelled = true)
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) {
            return;
        }
        Inventory top = event.getView().getTopInventory();
        if (top.getType() == InventoryType.CRAFTING) {
            return;
        }
        Inventory clicked = event.getClickedInventory();
        if (clicked == null) {
            return;
        }
        boolean moving = false;
        if (clicked.equals(top)) {
            moving = isSkillItem(event.getCursor());
            if (!moving && event.getClick() == ClickType.NUMBER_KEY && event.getHotbarButton() >= 0) {
                moving = isSkillItem(player.getInventory().getItem(event.getHotbarButton()));
            }
            if (!moving && event.getClick() == ClickType.SWAP_OFFHAND) {
                moving = isSkillItem(player.getInventory().getItemInOffHand());
            }
        } else if (event.isShiftClick()) {
            moving = isSkillItem(event.getCurrentItem());
        }
        if (moving) {
            event.setCancelled(true);
        }
    }

    @EventHandler(ignoreCancelled = true)
    public void onDrag(InventoryDragEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (top.getType() == InventoryType.CRAFTING || !isSkillItem(event.getOldCursor())) {
            return;
        }
        for (int slot : event.getRawSlots()) {
            if (slot < top.getSize()) {
                event.setCancelled(true);
                return;
            }
        }
    }

    // ---------- Furtivité et nettoyage ----------

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player player && manager().isStealthed(player.getUniqueId())) {
            manager().breakStealth(player);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onQuit(PlayerQuitEvent event) {
        manager().onQuit(event.getPlayer().getUniqueId());
    }
}
