package fr.legendaryclasses.menu;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.classes.ClassType;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.experience.ExperienceManager;
import fr.legendaryclasses.skill.SkillType;
import fr.legendaryclasses.util.ItemText;
import fr.legendaryclasses.util.MessageManager;
import fr.legendaryclasses.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Menu principal : les 5 classes. */
public final class ClassMenu implements Menu {

    private static final int[] CLASS_SLOTS = {11, 12, 13, 14, 15};
    private static final int SKILLS_SLOT = 18;
    private static final int CLOSE_SLOT = 22;

    private final LegendaryClassesPlugin plugin;
    private final Player player;
    private final Inventory inventory;
    private final Map<Integer, ClassType> slotMap = new HashMap<>();

    public ClassMenu(LegendaryClassesPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        this.inventory = Bukkit.createInventory(this, 27, plugin.getMessageManager().component("menu.classes-title"));
        render();
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void render() {
        MessageManager messages = plugin.getMessageManager();
        PlayerData data = plugin.getDataManager().get(player);
        inventory.clear();
        slotMap.clear();

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        fillerMeta.setHideTooltip(true);
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }
        if (data == null) {
            return;
        }
        ClassType[] types = ClassType.values();
        for (int i = 0; i < types.length; i++) {
            inventory.setItem(CLASS_SLOTS[i], buildClassItem(types[i], data));
            slotMap.put(CLASS_SLOTS[i], types[i]);
        }
        if (data.getClassType() != null) {
            inventory.setItem(SKILLS_SLOT, simpleItem(Material.BOOK,
                    messages.raw("menu.my-skills"), List.of(messages.raw("menu.my-skills-lore"))));
        }
        inventory.setItem(CLOSE_SLOT, simpleItem(Material.BARRIER, messages.raw("menu.close"), List.of()));
    }

    private ItemStack simpleItem(Material material, String name, List<String> lore) {
        MessageManager messages = plugin.getMessageManager();
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(ItemText.line(messages, name));
        meta.lore(ItemText.lines(messages, lore));
        item.setItemMeta(meta);
        return item;
    }

    private ItemStack buildClassItem(ClassType type, PlayerData data) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();
        ExperienceManager experience = plugin.getExperienceManager();

        ItemStack item = new ItemStack(type.getIcon());
        ItemMeta meta = item.getItemMeta();
        meta.displayName(ItemText.line(messages, classManager.getDisplayName(type)));

        List<String> lore = new ArrayList<>(classManager.getDescription(type));
        lore.add("");
        lore.add(messages.raw("menu.specialty", "specialty", classManager.getSpecialty(type)));
        lore.add(messages.raw("menu.max-level", "max", experience.getMaxLevel()));
        lore.add("");
        lore.add(messages.raw("menu.skills-header"));
        for (SkillType skill : SkillType.forClass(type)) {
            lore.add(messages.raw("menu.skill-line",
                    "skill", classManager.getSkillName(skill),
                    "level", classManager.getUnlockLevel(skill)));
        }
        lore.add("");
        if (data.getClassType() == type) {
            boolean maxed = data.getLevel() >= experience.getMaxLevel();
            lore.add(messages.raw("menu.selected"));
            lore.add(messages.raw("menu.level-info",
                    "level", data.getLevel(),
                    "max", experience.getMaxLevel(),
                    "xp", maxed ? messages.raw("level.max-label") : String.valueOf(data.getXp()),
                    "needed", maxed ? messages.raw("level.max-label")
                            : String.valueOf(experience.getXpForNextLevel(data.getLevel()))));
            meta.setEnchantmentGlintOverride(true);
        } else if (data.getClassType() == null) {
            lore.add(messages.raw("menu.click-choose"));
        } else {
            lore.add(messages.raw("menu.locked-other"));
        }
        meta.lore(ItemText.lines(messages, lore));
        meta.addItemFlags(ItemFlag.HIDE_ATTRIBUTES);
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        int slot = event.getSlot();
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            return;
        }
        if (slot == CLOSE_SLOT) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-close"), 0.8f, 1f);
            Bukkit.getScheduler().runTask(plugin, () -> player.closeInventory());
            return;
        }
        if (slot == SKILLS_SLOT && data.getClassType() != null) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-click"), 0.8f, 1f);
            Bukkit.getScheduler().runTask(plugin, () -> plugin.getMenuManager().openSkillMenu(player));
            return;
        }
        ClassType type = slotMap.get(slot);
        if (type == null) {
            return;
        }
        if (data.getClassType() == null) {
            plugin.getClassManager().chooseClass(player, data, type);
            render();
        } else if (data.getClassType() != type) {
            plugin.getMessageManager().send(player, "class.already");
        }
    }
}
