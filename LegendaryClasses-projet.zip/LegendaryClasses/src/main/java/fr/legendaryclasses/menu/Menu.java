package fr.legendaryclasses.menu;

import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

/** Un menu du plugin : l'inventaire est identifié par son holder, jamais par son titre. */
public interface Menu extends InventoryHolder {
    /** Appelé uniquement pour un clic dans l'inventaire du menu (l'événement est déjà annulé). */
    void handleClick(InventoryClickEvent event);
}
