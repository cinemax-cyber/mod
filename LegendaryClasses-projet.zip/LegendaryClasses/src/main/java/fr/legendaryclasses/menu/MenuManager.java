package fr.legendaryclasses.menu;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.util.SoundUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;

public final class MenuManager implements Listener {

    private final LegendaryClassesPlugin plugin;

    public MenuManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    public void openClassMenu(Player player) {
        if (plugin.getDataManager().get(player) == null) {
            plugin.getMessageManager().send(player, "general.data-not-loaded");
            return;
        }
        ClassMenu menu = new ClassMenu(plugin, player);
        player.openInventory(menu.getInventory());
        SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-open"), 0.8f, 1.2f);
    }

    public void openSkillMenu(Player player) {
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            plugin.getMessageManager().send(player, "general.data-not-loaded");
            return;
        }
        if (data.getClassType() == null) {
            plugin.getMessageManager().send(player, "menu.no-class");
            return;
        }
        SkillMenu menu = new SkillMenu(plugin, player);
        player.openInventory(menu.getInventory());
        SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-open"), 0.8f, 1.2f);
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onClick(InventoryClickEvent event) {
        Inventory top = event.getView().getTopInventory();
        if (!(top.getHolder() instanceof Menu menu)) {
            return;
        }
        event.setCancelled(true); // aucun objet ne peut entrer, sortir ni être déplacé
        if (!(event.getWhoClicked() instanceof Player)) {
            return;
        }
        Inventory clicked = event.getClickedInventory();
        if (clicked != null && clicked.equals(top)) {
            menu.handleClick(event);
        }
    }

    @EventHandler(priority = EventPriority.HIGH)
    public void onDrag(InventoryDragEvent event) {
        if (event.getView().getTopInventory().getHolder() instanceof Menu) {
            event.setCancelled(true);
        }
    }
}
