package fr.legendaryclasses.menu;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import fr.legendaryclasses.util.ItemText;
import fr.legendaryclasses.util.MessageManager;
import fr.legendaryclasses.util.SoundUtil;
import net.kyori.adventure.text.Component;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Menu des compétences de la classe du joueur (débloquées et verrouillées). */
public final class SkillMenu implements Menu {

    private static final int[] SKILL_SLOTS = {11, 12, 13, 14, 15};
    private static final int BACK_SLOT = 18;
    private static final int CLOSE_SLOT = 22;

    private final LegendaryClassesPlugin plugin;
    private final Player player;
    private final Inventory inventory;
    private final Map<Integer, SkillType> slotMap = new HashMap<>();

    public SkillMenu(LegendaryClassesPlugin plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        PlayerData data = plugin.getDataManager().get(player);
        Component title = plugin.getMessageManager().component("menu.skills-title",
                "class", plugin.getClassManager().getDisplayName(data.getClassType()));
        this.inventory = Bukkit.createInventory(this, 27, title);
        render(data);
    }

    @Override
    public Inventory getInventory() {
        return inventory;
    }

    private void render(PlayerData data) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();
        SkillManager skillManager = plugin.getSkillManager();

        ItemStack filler = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
        ItemMeta fillerMeta = filler.getItemMeta();
        fillerMeta.displayName(Component.empty());
        fillerMeta.setHideTooltip(true);
        filler.setItemMeta(fillerMeta);
        for (int i = 0; i < inventory.getSize(); i++) {
            inventory.setItem(i, filler);
        }

        List<SkillType> skills = SkillType.forClass(data.getClassType());
        for (int i = 0; i < skills.size() && i < SKILL_SLOTS.length; i++) {
            SkillType skill = skills.get(i);
            boolean unlocked = classManager.isUnlocked(data, skill);
            int unlockLevel = classManager.getUnlockLevel(skill);
            double cooldown = plugin.getConfig().getDouble(skill.getConfigPath() + ".cooldown", 10);
            String name = classManager.getSkillName(skill);

            List<String> lore = new ArrayList<>();
            lore.add("&7" + classManager.getSkillDescription(skill));
            lore.add("");
            lore.add(messages.raw("menu.skill-cooldown", "cooldown", SkillManager.formatSeconds((long) (cooldown * 1000))));

            ItemStack item;
            ItemMeta meta;
            if (unlocked) {
                item = new ItemStack(skillManager.getItems().getMaterial(data.getClassType()));
                meta = item.getItemMeta();
                meta.displayName(ItemText.line(messages, messages.raw("menu.skill-unlocked-name", "skill", name)));
                long remaining = skillManager.getCooldowns().getRemainingMillis(player.getUniqueId(), skill);
                lore.add(remaining > 0
                        ? messages.raw("menu.skill-remaining", "time", SkillManager.formatSeconds(remaining))
                        : messages.raw("menu.skill-ready"));
                lore.add("");
                lore.add(messages.raw("menu.skill-unlocked-hint"));
                meta.setEnchantmentGlintOverride(true);
            } else {
                item = new ItemStack(Material.RED_STAINED_GLASS_PANE);
                meta = item.getItemMeta();
                meta.displayName(ItemText.line(messages, messages.raw("menu.skill-locked", "skill", name)));
                lore.add(messages.raw("menu.skill-locked-lore", "level", unlockLevel));
            }
            meta.lore(ItemText.lines(messages, lore));
            item.setItemMeta(meta);
            inventory.setItem(SKILL_SLOTS[i], item);
            slotMap.put(SKILL_SLOTS[i], skill);
        }

        inventory.setItem(BACK_SLOT, button(Material.ARROW, messages.raw("menu.back")));
        inventory.setItem(CLOSE_SLOT, button(Material.BARRIER, messages.raw("menu.close")));
    }

    private ItemStack button(Material material, String name) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.displayName(ItemText.line(plugin.getMessageManager(), name));
        item.setItemMeta(meta);
        return item;
    }

    @Override
    public void handleClick(InventoryClickEvent event) {
        int slot = event.getSlot();
        if (slot == CLOSE_SLOT) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-close"), 0.8f, 1f);
            Bukkit.getScheduler().runTask(plugin, () -> player.closeInventory());
            return;
        }
        if (slot == BACK_SLOT) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-click"), 0.8f, 1f);
            Bukkit.getScheduler().runTask(plugin, () -> plugin.getMenuManager().openClassMenu(player));
            return;
        }
        SkillType skill = slotMap.get(slot);
        if (skill != null) {
            SoundUtil.play(player, plugin.getConfig().getString("sounds.menu-click"), 0.8f, 1.2f);
            plugin.getSkillManager().getItems().requestItem(player, skill);
        }
    }
}
