package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import org.bukkit.FluidCollisionMode;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.block.Block;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.ArmorStand;
import org.bukkit.entity.Enemy;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Tameable;
import org.bukkit.entity.Villager;
import org.bukkit.entity.WanderingTrader;
import org.bukkit.scoreboard.Team;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

/** Ciblage, validation des cibles (PvP, équipes, zones) et application des dégâts. */
public final class Combat {

    private final LegendaryClassesPlugin plugin;
    private final SkillProtection protection;
    private boolean pvpEnabled = true;
    private double pvpMultiplier = 0.6;
    private double pvpMaxHit = 12.0;
    private boolean rapidOnPlayers = true;
    private boolean respectTeams = true;
    private boolean hitPassive = true;

    public Combat(LegendaryClassesPlugin plugin, SkillProtection protection) {
        this.plugin = plugin;
        this.protection = protection;
    }

    public void reload() {
        FileConfiguration config = plugin.getConfig();
        pvpEnabled = config.getBoolean("pvp.enabled", true);
        pvpMultiplier = Math.max(0.0, config.getDouble("pvp.damage-multiplier", 0.6));
        pvpMaxHit = Math.max(0.5, config.getDouble("pvp.max-damage-per-hit", 12.0));
        rapidOnPlayers = config.getBoolean("pvp.rapid-hits-on-players", true);
        respectTeams = config.getBoolean("combat.respect-teams", true);
        hitPassive = config.getBoolean("combat.hit-passive-mobs", true);
    }

    // ---------- Validation ----------

    public boolean canHarm(Player caster, Entity entity) {
        if (!(entity instanceof LivingEntity target)) {
            return false;
        }
        if (target.equals(caster) || target.isDead() || !target.isValid() || target.isInvulnerable()) {
            return false;
        }
        if (!target.getWorld().equals(caster.getWorld())) {
            return false;
        }
        if (target instanceof ArmorStand || target instanceof Villager || target instanceof WanderingTrader) {
            return false;
        }
        if (target instanceof Tameable tameable && tameable.isTamed()) {
            return false;
        }
        if (target instanceof Player other) {
            if (!pvpEnabled || !target.getWorld().getPVP()) {
                return false;
            }
            GameMode mode = other.getGameMode();
            if (mode == GameMode.CREATIVE || mode == GameMode.SPECTATOR) {
                return false;
            }
            if (respectTeams) {
                Team team = caster.getScoreboard().getEntryTeam(caster.getName());
                if (team != null && team.hasEntry(other.getName()) && !team.allowFriendlyFire()) {
                    return false;
                }
            }
        } else if (!hitPassive && !(target instanceof Enemy)) {
            return false;
        }
        return !protection.isProtected(target.getLocation());
    }

    // ---------- Dégâts ----------

    public double finalDamage(LivingEntity target, double amount) {
        if (target instanceof Player) {
            return Math.min(amount * pvpMultiplier, pvpMaxHit);
        }
        return amount;
    }

    /** Inflige des dégâts attribués au joueur (déclenche les événements, donc les plugins de protection). */
    public boolean hit(Player caster, LivingEntity target, double amount, boolean rapid) {
        if (!canHarm(caster, target)) {
            return false;
        }
        if (rapid && (!(target instanceof Player) || rapidOnPlayers)) {
            target.setNoDamageTicks(0);
        }
        target.damage(finalDamage(target, amount), caster);
        return true;
    }

    public void knockback(LivingEntity target, Location from, double strength, double lift) {
        Vector direction = target.getLocation().toVector().subtract(from.toVector());
        direction.setY(0);
        if (direction.lengthSquared() < 1.0E-4) {
            direction = new Vector(0, 0, 0);
        } else {
            direction.normalize().multiply(strength);
        }
        direction.setY(lift);
        target.setVelocity(direction);
    }

    public void heal(Player player, double amount) {
        AttributeInstance max = player.getAttribute(Attribute.MAX_HEALTH);
        double maxHealth = max == null ? 20.0 : max.getValue();
        player.setHealth(Math.min(maxHealth, player.getHealth() + Math.max(0.0, amount)));
    }

    // ---------- Ciblage ----------

    public LivingEntity findTarget(Player caster, double range) {
        Location eye = caster.getEyeLocation();
        RayTraceResult result = caster.getWorld().rayTrace(eye, eye.getDirection(), range,
                FluidCollisionMode.NEVER, true, 0.5, entity -> canHarm(caster, entity));
        if (result != null && result.getHitEntity() instanceof LivingEntity living) {
            return living;
        }
        return null;
    }

    /** Point visé (bloc ou entité). Si rien n'est touché : null si requireHit, sinon l'extrémité du rayon. */
    public Location aimPoint(Player caster, double range, boolean requireHit) {
        Location eye = caster.getEyeLocation();
        Vector direction = eye.getDirection();
        RayTraceResult result = caster.getWorld().rayTrace(eye, direction, range,
                FluidCollisionMode.NEVER, true, 0.4, entity -> canHarm(caster, entity));
        if (result != null) {
            return result.getHitPosition().toLocation(caster.getWorld());
        }
        if (requireHit) {
            return null;
        }
        return eye.clone().add(direction.multiply(range));
    }

    /** Descend jusqu'au premier bloc solide (40 blocs max) pour poser un effet au sol. */
    public Location snapToGround(Location location) {
        World world = location.getWorld();
        if (world == null) {
            return location;
        }
        Location probe = location.clone();
        for (int i = 0; i < 40 && probe.getBlockY() > world.getMinHeight(); i++) {
            if (!probe.getBlock().isPassable()) {
                probe.setY(probe.getBlockY() + 1.0);
                return probe;
            }
            probe.subtract(0, 1, 0);
        }
        return location;
    }

    public List<LivingEntity> nearby(Player caster, Location center, double radius) {
        List<LivingEntity> result = new ArrayList<>();
        if (center.getWorld() == null) {
            return result;
        }
        double radiusSquared = radius * radius;
        Vector centerVector = center.toVector();
        for (LivingEntity entity : center.getWorld().getNearbyLivingEntities(center, radius)) {
            if (entity.getBoundingBox().getCenter().distanceSquared(centerVector) <= radiusSquared
                    && canHarm(caster, entity)) {
                result.add(entity);
            }
        }
        return result;
    }

    public LivingEntity nearestTarget(Player caster, double radius, boolean requireLineOfSight) {
        LivingEntity best = null;
        double bestDistance = Double.MAX_VALUE;
        for (LivingEntity entity : nearby(caster, caster.getLocation(), radius)) {
            if (requireLineOfSight && !caster.hasLineOfSight(entity)) {
                continue;
            }
            double distance = entity.getLocation().distanceSquared(caster.getLocation());
            if (distance < bestDistance) {
                bestDistance = distance;
                best = entity;
            }
        }
        return best;
    }

    /** Cible la mieux alignée avec le regard du joueur (minDot : 1 = exactement devant). */
    public LivingEntity bestTargetInView(Player caster, double radius, double minDot) {
        Vector look = caster.getEyeLocation().getDirection();
        Vector eye = caster.getEyeLocation().toVector();
        LivingEntity best = null;
        double bestScore = -10.0;
        for (LivingEntity entity : nearby(caster, caster.getLocation(), radius)) {
            if (!caster.hasLineOfSight(entity)) {
                continue;
            }
            Vector toTarget = entity.getBoundingBox().getCenter().subtract(eye);
            if (toTarget.lengthSquared() < 1.0E-4) {
                continue;
            }
            double dot = look.dot(toTarget.clone().normalize());
            if (dot < minDot) {
                continue;
            }
            double score = dot - toTarget.length() * 0.01;
            if (score > bestScore) {
                bestScore = score;
                best = entity;
            }
        }
        return best;
    }

    /** Position sûre derrière (ou à côté de) la cible, ou null si aucune place libre. */
    public Location behind(LivingEntity target, double distance) {
        Location base = target.getLocation();
        Vector back = base.getDirection().setY(0);
        if (back.lengthSquared() < 1.0E-4) {
            back = new Vector(1, 0, 0);
        }
        back.normalize().multiply(-distance);
        Vector[] offsets = {
                back,
                back.clone().rotateAroundY(Math.PI / 2),
                back.clone().rotateAroundY(-Math.PI / 2),
                back.clone().multiply(-1)
        };
        for (Vector offset : offsets) {
            Location candidate = base.clone().add(offset);
            if (isSafe(candidate)) {
                return candidate;
            }
        }
        return null;
    }

    private boolean isSafe(Location location) {
        Block feet = location.getBlock();
        Block head = feet.getRelative(0, 1, 0);
        Block ground = feet.getRelative(0, -1, 0);
        return feet.isPassable() && !feet.isLiquid()
                && head.isPassable() && !head.isLiquid()
                && ground.getType().isSolid()
                && !protection.isProtected(location);
    }
}
