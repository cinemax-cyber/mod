package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

/** Particules et sons, avec budget configurable. Les clés inconnues sont ignorées sans erreur. */
public final class Fx {

    private final LegendaryClassesPlugin plugin;
    private final Map<String, Particle> particles = new HashMap<>();
    private final Set<String> unknown = new HashSet<>();
    private boolean particlesEnabled = true;
    private boolean soundsEnabled = true;
    private double multiplier = 1.0;
    private int maxPerCall = 60;

    public Fx(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    public void reload() {
        FileConfiguration config = plugin.getConfig();
        particlesEnabled = config.getBoolean("effects.particles-enabled", true);
        soundsEnabled = config.getBoolean("effects.sounds-enabled", true);
        multiplier = Math.max(0.0, config.getDouble("effects.particle-multiplier", 1.0));
        maxPerCall = Math.max(1, config.getInt("effects.max-particles-per-call", 60));
    }

    private Particle resolve(String key) {
        Particle cached = particles.get(key);
        if (cached != null) {
            return cached;
        }
        if (unknown.contains(key)) {
            return null;
        }
        Particle particle = Registry.PARTICLE_TYPE.get(NamespacedKey.minecraft(key));
        if (particle == null || particle.getDataType() != Void.class) {
            unknown.add(key);
            return null;
        }
        particles.put(key, particle);
        return particle;
    }

    private boolean off() {
        return !particlesEnabled || multiplier <= 0.0;
    }

    /** Une salve de particules (nombre ajusté par le multiplicateur et plafonné). */
    public void particle(Location loc, String key, int count, double ox, double oy, double oz, double speed) {
        if (off() || loc.getWorld() == null) {
            return;
        }
        Particle particle = resolve(key);
        if (particle == null) {
            return;
        }
        int n = Math.max(1, Math.min(maxPerCall, (int) Math.round(count * multiplier)));
        loc.getWorld().spawnParticle(particle, loc, n, ox, oy, oz, speed);
    }

    public void dust(Location loc, int r, int g, int b, float size, int count, double spread) {
        if (off() || loc.getWorld() == null) {
            return;
        }
        int n = Math.max(1, Math.min(maxPerCall, (int) Math.round(count * multiplier)));
        loc.getWorld().spawnParticle(Particle.DUST, loc, n, spread, spread, spread, 0.0,
                new Particle.DustOptions(Color.fromRGB(r, g, b), size));
    }

    public void ring(Location center, String key, double radius, int points) {
        if (off() || center.getWorld() == null) {
            return;
        }
        Particle particle = resolve(key);
        if (particle == null) {
            return;
        }
        World world = center.getWorld();
        int n = Math.max(6, Math.min(maxPerCall, (int) Math.round(points * multiplier)));
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            world.spawnParticle(particle, center.getX() + Math.cos(angle) * radius, center.getY(),
                    center.getZ() + Math.sin(angle) * radius, 1, 0, 0, 0, 0.0);
        }
    }

    public void dustRing(Location center, double radius, int points, int r, int g, int b, float size) {
        if (off() || center.getWorld() == null) {
            return;
        }
        World world = center.getWorld();
        Particle.DustOptions options = new Particle.DustOptions(Color.fromRGB(r, g, b), size);
        int n = Math.max(6, Math.min(maxPerCall, (int) Math.round(points * multiplier)));
        for (int i = 0; i < n; i++) {
            double angle = 2 * Math.PI * i / n;
            world.spawnParticle(Particle.DUST, center.getX() + Math.cos(angle) * radius, center.getY(),
                    center.getZ() + Math.sin(angle) * radius, 1, 0, 0, 0, 0.0, options);
        }
    }

    public void line(Location from, Location to, String key, int points) {
        if (off() || from.getWorld() == null) {
            return;
        }
        Particle particle = resolve(key);
        if (particle == null) {
            return;
        }
        World world = from.getWorld();
        int n = Math.max(2, Math.min(maxPerCall, (int) Math.round(points * multiplier)));
        Vector start = from.toVector();
        Vector step = to.toVector().subtract(start);
        for (int i = 0; i <= n; i++) {
            Vector point = start.clone().add(step.clone().multiply((double) i / n));
            world.spawnParticle(particle, point.getX(), point.getY(), point.getZ(), 1, 0, 0, 0, 0.0);
        }
    }

    public void sound(Location loc, String key, float volume, float pitch) {
        if (!soundsEnabled || loc.getWorld() == null) {
            return;
        }
        Sound sound = Registry.SOUNDS.get(NamespacedKey.minecraft(key));
        if (sound == null) {
            return;
        }
        loc.getWorld().playSound(loc, sound, SoundCategory.PLAYERS, volume, pitch);
    }
}
