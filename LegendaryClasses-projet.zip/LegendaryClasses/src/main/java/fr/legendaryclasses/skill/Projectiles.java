package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import org.bukkit.FluidCollisionMode;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

/** Projectiles « logiques » : lancer de rayon à chaque tick, aucune entité, aucun bloc modifié. */
public final class Projectiles {

    @FunctionalInterface
    public interface Impact {
        /** where : point d'impact ; direct : entité touchée directement (null si bloc ou fin de course). */
        void onImpact(Location where, LivingEntity direct);
    }

    private final LegendaryClassesPlugin plugin;
    private final Combat combat;
    private final Fx fx;

    public Projectiles(LegendaryClassesPlugin plugin, Combat combat, Fx fx) {
        this.plugin = plugin;
        this.combat = combat;
        this.fx = fx;
    }

    public void launch(Player caster, Location start, Vector direction, double speed, double maxRange,
                       double hitRadius, String trail, Impact impact) {
        final Vector dir = direction.clone().normalize();
        final Location pos = start.clone();
        new BukkitRunnable() {
            private double travelled = 0.0;

            @Override
            public void run() {
                World world = pos.getWorld();
                if (!caster.isOnline() || world == null) {
                    cancel();
                    return;
                }
                RayTraceResult result = world.rayTrace(pos, dir, speed, FluidCollisionMode.NEVER, true,
                        hitRadius, entity -> combat.canHarm(caster, entity));
                if (result != null) {
                    Location where = result.getHitPosition().toLocation(world);
                    cancel();
                    fx.line(pos, where, trail, 3);
                    Entity hit = result.getHitEntity();
                    safeImpact(impact, where, hit instanceof LivingEntity living ? living : null);
                    return;
                }
                pos.add(dir.clone().multiply(speed));
                travelled += speed;
                fx.particle(pos, trail, 2, 0.03, 0.03, 0.03, 0.0);
                if (travelled >= maxRange) {
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    /** Projectile à tête chercheuse : corrige sa trajectoire vers la cible à chaque tick. */
    public void launchHoming(Player caster, Location start, Vector initialDirection, LivingEntity target,
                             double speed, int maxTicks, double hitDistance, String trail, Impact impact) {
        final Vector dir = initialDirection.clone().normalize();
        final Location pos = start.clone();
        new BukkitRunnable() {
            private int ticks = 0;

            @Override
            public void run() {
                World world = pos.getWorld();
                if (!caster.isOnline() || world == null || ticks++ >= maxTicks
                        || target.isDead() || !target.isValid() || !target.getWorld().equals(world)) {
                    cancel();
                    return;
                }
                Vector desired = target.getBoundingBox().getCenter().subtract(pos.toVector());
                if (desired.length() <= hitDistance) {
                    cancel();
                    safeImpact(impact, pos.clone(), target);
                    return;
                }
                dir.multiply(0.65).add(desired.normalize().multiply(0.35)).normalize();
                RayTraceResult wall = world.rayTraceBlocks(pos, dir, speed, FluidCollisionMode.NEVER, true);
                if (wall != null) {
                    cancel();
                    safeImpact(impact, wall.getHitPosition().toLocation(world), null);
                    return;
                }
                pos.add(dir.clone().multiply(speed));
                fx.particle(pos, trail, 2, 0.03, 0.03, 0.03, 0.0);
            }
        }.runTaskTimer(plugin, 0L, 1L);
    }

    private void safeImpact(Impact impact, Location where, LivingEntity direct) {
        try {
            impact.onImpact(where, direct);
        } catch (RuntimeException ex) {
            plugin.getLogger().warning("Erreur lors d'un impact de compétence : " + ex);
        }
    }
}
