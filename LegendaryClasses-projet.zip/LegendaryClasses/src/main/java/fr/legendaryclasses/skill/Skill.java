package fr.legendaryclasses.skill;

public final class Skill {

    private final SkillType type;
    private final SkillExecutor executor;

    public Skill(SkillType type, SkillExecutor executor) {
        this.type = type;
        this.executor = executor;
    }

    public SkillType getType() {
        return type;
    }

    public boolean cast(SkillContext context) {
        return executor.cast(context);
    }
}
