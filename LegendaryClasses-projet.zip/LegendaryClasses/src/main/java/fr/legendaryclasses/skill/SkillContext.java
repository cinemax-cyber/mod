package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.function.IntPredicate;

/** Tout ce dont une compétence a besoin : lanceur, configuration, outils de combat et d'effets. */
public final class SkillContext {

    private final LegendaryClassesPlugin plugin;
    private final SkillManager manager;
    private final Player player;
    private final SkillType skill;

    public SkillContext(LegendaryClassesPlugin plugin, SkillManager manager, Player player, SkillType skill) {
        this.plugin = plugin;
        this.manager = manager;
        this.player = player;
        this.skill = skill;
    }

    public LegendaryClassesPlugin plugin() { return plugin; }

    public SkillManager manager() { return manager; }

    public Player player() { return player; }

    public SkillType skill() { return skill; }

    public Combat combat() { return manager.getCombat(); }

    public Fx fx() { return manager.getFx(); }

    public Projectiles projectiles() { return manager.getProjectiles(); }

    /** Valeur numérique de skills.<classe>.<compétence>.<clé>. */
    public double num(String key, double def) {
        return plugin.getConfig().getDouble(skill.getConfigPath() + "." + key, def);
    }

    public boolean bool(String key, boolean def) {
        return plugin.getConfig().getBoolean(skill.getConfigPath() + "." + key, def);
    }

    /** Envoie un message d'échec au joueur et retourne false. */
    public boolean fail(String messageKey) {
        plugin.getMessageManager().send(player, messageKey);
        return false;
    }

    public void later(long ticks, Runnable task) {
        Bukkit.getScheduler().runTaskLater(plugin, task, Math.max(1L, ticks));
    }

    /**
     * Exécute step(i) maintenant puis toutes les periodTicks, au plus "times" fois.
     * La tâche s'arrête seule dès que step retourne false : aucune tâche orpheline.
     */
    public void repeat(long periodTicks, int times, IntPredicate step) {
        new BukkitRunnable() {
            private int index = 0;

            @Override
            public void run() {
                boolean keepGoing;
                try {
                    keepGoing = step.test(index);
                } catch (RuntimeException ex) {
                    plugin.getLogger().warning("Erreur dans " + skill.getId() + " : " + ex);
                    cancel();
                    return;
                }
                if (!keepGoing) {
                    cancel();
                    return;
                }
                index++;
                if (index >= times) {
                    cancel();
                }
            }
        }.runTaskTimer(plugin, 0L, Math.max(1L, periodTicks));
    }
}
