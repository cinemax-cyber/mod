package fr.legendaryclasses.skill;

@FunctionalInterface
public interface SkillExecutor {
    /** Exécute la compétence. Retourne false si elle n'a pas pu être lancée (aucun recharge consommé). */
    boolean cast(SkillContext context);
}
