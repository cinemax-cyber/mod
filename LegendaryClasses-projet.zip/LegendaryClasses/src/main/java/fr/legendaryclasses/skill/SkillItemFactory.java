package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.classes.ClassType;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.util.ItemText;
import fr.legendaryclasses.util.MessageManager;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.Optional;
import java.util.UUID;

/** Objets de compétence : identifiés par PersistentDataContainer (survivent aux redémarrages), liés à un propriétaire. */
public final class SkillItemFactory {

    public enum GiveResult { GIVEN, ALREADY_OWNED, NO_SPACE }

    private final LegendaryClassesPlugin plugin;
    private final NamespacedKey skillKey;
    private final NamespacedKey ownerKey;

    public SkillItemFactory(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
        this.skillKey = new NamespacedKey(plugin, "skill_id");
        this.ownerKey = new NamespacedKey(plugin, "skill_owner");
    }

    public Material getMaterial(ClassType type) {
        String fallback = switch (type) {
            case GUERRIER -> "IRON_INGOT";
            case ASSASSIN -> "PHANTOM_MEMBRANE";
            case MAGE -> "BLAZE_ROD";
            case ARCHER -> "FEATHER";
            case FAUCHEUR -> "NETHERITE_SCRAP";
        };
        String name = plugin.getConfig().getString("skill-items.materials." + type.getId(), fallback);
        Material material = Material.matchMaterial(name);
        return material == null || !material.isItem() ? Material.NETHER_STAR : material;
    }

    public ItemStack create(Player owner, SkillType skill) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();
        ItemStack item = new ItemStack(getMaterial(skill.getClassType()));
        ItemMeta meta = item.getItemMeta();
        meta.displayName(ItemText.line(messages, messages.raw("skill-item.name",
                "skill", classManager.getSkillName(skill))));
        double cooldown = plugin.getConfig().getDouble(skill.getConfigPath() + ".cooldown", 10);
        meta.lore(ItemText.lines(messages, messages.rawList("skill-item.lore",
                "description", classManager.getSkillDescription(skill),
                "class", classManager.getDisplayName(skill.getClassType()),
                "level", classManager.getUnlockLevel(skill),
                "cooldown", SkillManager.formatSeconds((long) (cooldown * 1000)),
                "owner", owner.getName())));
        meta.setEnchantmentGlintOverride(true);
        meta.getPersistentDataContainer().set(skillKey, PersistentDataType.STRING, skill.getId());
        meta.getPersistentDataContainer().set(ownerKey, PersistentDataType.STRING, owner.getUniqueId().toString());
        item.setItemMeta(meta);
        return item;
    }

    public Optional<SkillType> getSkill(ItemStack item) {
        if (item == null || item.getType().isAir() || !item.hasItemMeta()) {
            return Optional.empty();
        }
        String id = item.getItemMeta().getPersistentDataContainer().get(skillKey, PersistentDataType.STRING);
        return SkillType.fromId(id);
    }

    public boolean isOwner(ItemStack item, UUID uuid) {
        if (item == null || !item.hasItemMeta()) {
            return false;
        }
        String owner = item.getItemMeta().getPersistentDataContainer().get(ownerKey, PersistentDataType.STRING);
        return uuid.toString().equals(owner);
    }

    public boolean hasItem(Player player, SkillType skill) {
        for (ItemStack stack : player.getInventory().getContents()) {
            if (stack != null && getSkill(stack).filter(found -> found == skill).isPresent()
                    && isOwner(stack, player.getUniqueId())) {
                return true;
            }
        }
        ItemStack cursor = player.getItemOnCursor();
        return getSkill(cursor).filter(found -> found == skill).isPresent();
    }

    public GiveResult give(Player player, SkillType skill) {
        if (hasItem(player, skill)) {
            return GiveResult.ALREADY_OWNED;
        }
        return player.getInventory().addItem(create(player, skill)).isEmpty()
                ? GiveResult.GIVEN : GiveResult.NO_SPACE;
    }

    /** Vérifie classe et niveau, donne l'objet et informe le joueur. */
    public void requestItem(Player player, SkillType skill) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            messages.send(player, "general.data-not-loaded");
            return;
        }
        if (data.getClassType() == null) {
            messages.send(player, "class.none");
            return;
        }
        String name = classManager.getSkillName(skill);
        if (data.getClassType() != skill.getClassType()) {
            messages.send(player, "skill.wrong-class", "skill", name);
            return;
        }
        int unlock = classManager.getUnlockLevel(skill);
        if (data.getLevel() < unlock) {
            messages.send(player, "skill.locked", "skill", name, "level", unlock);
            return;
        }
        switch (give(player, skill)) {
            case GIVEN -> messages.send(player, "skill.item-given", "skill", name);
            case ALREADY_OWNED -> messages.send(player, "skill.item-already", "skill", name);
            case NO_SPACE -> messages.send(player, "skill.item-no-space");
        }
    }
}
