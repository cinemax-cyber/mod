package fr.legendaryclasses.skill;

import fr.legendaryclasses.LegendaryClassesPlugin;
import fr.legendaryclasses.classes.ClassManager;
import fr.legendaryclasses.cooldown.CooldownManager;
import fr.legendaryclasses.data.PlayerData;
import fr.legendaryclasses.skill.archer.ArcherSkills;
import fr.legendaryclasses.skill.assassin.AssassinSkills;
import fr.legendaryclasses.skill.faucheur.FaucheurSkills;
import fr.legendaryclasses.skill.guerrier.GuerrierSkills;
import fr.legendaryclasses.skill.mage.MageSkills;
import fr.legendaryclasses.util.MessageManager;
import org.bukkit.GameMode;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.util.EnumMap;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public final class SkillManager {

    public enum CastResult {
        SUCCESS, NO_DATA, NO_CLASS, WRONG_CLASS, LOCKED, NO_PERMISSION,
        WORLD_DISABLED, SAFE_ZONE, INVALID_STATE, GLOBAL_LOCK, COOLDOWN, FAILED
    }

    private final LegendaryClassesPlugin plugin;
    private final Map<SkillType, Skill> skills = new EnumMap<>(SkillType.class);
    private final CooldownManager cooldowns = new CooldownManager();
    private final SkillProtection protection;
    private final Fx fx;
    private final Combat combat;
    private final Projectiles projectiles;
    private final SkillItemFactory items;
    private final Map<UUID, Long> lastCast = new HashMap<>();
    private final Map<UUID, Long> stealth = new HashMap<>();
    private final Set<String> disabledWorlds = new HashSet<>();
    private long globalCooldownMs = 400L;
    private boolean blockInSafeZones = true;

    public SkillManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
        this.protection = new SkillProtection(plugin.getLogger());
        this.fx = new Fx(plugin);
        this.combat = new Combat(plugin, protection);
        this.projectiles = new Projectiles(plugin, combat, fx);
        this.items = new SkillItemFactory(plugin);

        GuerrierSkills.register(this);
        AssassinSkills.register(this);
        MageSkills.register(this);
        ArcherSkills.register(this);
        FaucheurSkills.register(this);
        for (SkillType type : SkillType.values()) {
            if (!skills.containsKey(type)) {
                plugin.getLogger().warning("Compétence non implémentée : " + type.getId());
            }
        }
    }

    public void register(Skill skill) {
        skills.put(skill.getType(), skill);
    }

    public void reload() {
        FileConfiguration config = plugin.getConfig();
        fx.reload();
        combat.reload();
        protection.reload(config);
        globalCooldownMs = Math.max(0L, config.getLong("skill-settings.global-cooldown-ms", 400L));
        blockInSafeZones = config.getBoolean("protection.block-casting-in-safe-zones", true);
        disabledWorlds.clear();
        for (String world : config.getStringList("skill-settings.disabled-worlds")) {
            disabledWorlds.add(world.toLowerCase(Locale.ROOT));
        }
    }

    // ---------- Lancement ----------

    public CastResult cast(Player player, SkillType type) {
        MessageManager messages = plugin.getMessageManager();
        ClassManager classManager = plugin.getClassManager();
        PlayerData data = plugin.getDataManager().get(player);
        if (data == null) {
            messages.send(player, "general.data-not-loaded");
            return CastResult.NO_DATA;
        }
        if (data.getClassType() == null) {
            messages.send(player, "class.none");
            return CastResult.NO_CLASS;
        }
        String name = classManager.getSkillName(type);
        if (data.getClassType() != type.getClassType()) {
            messages.send(player, "skill.wrong-class", "skill", name);
            return CastResult.WRONG_CLASS;
        }
        int unlock = classManager.getUnlockLevel(type);
        if (data.getLevel() < unlock) {
            messages.send(player, "skill.locked", "skill", name, "level", unlock);
            return CastResult.LOCKED;
        }
        if (!player.hasPermission("legendaryclasses.skills.use")) {
            messages.send(player, "general.no-permission");
            return CastResult.NO_PERMISSION;
        }
        if (player.isDead() || player.getGameMode() == GameMode.SPECTATOR) {
            return CastResult.INVALID_STATE;
        }
        if (disabledWorlds.contains(player.getWorld().getName().toLowerCase(Locale.ROOT))) {
            messages.send(player, "skill.world-disabled");
            return CastResult.WORLD_DISABLED;
        }
        if (blockInSafeZones && protection.isProtected(player.getLocation())) {
            messages.send(player, "skill.safe-zone");
            return CastResult.SAFE_ZONE;
        }

        UUID uuid = player.getUniqueId();
        long now = System.currentTimeMillis();
        Long last = lastCast.get(uuid);
        if (last != null && now - last < globalCooldownMs) {
            return CastResult.GLOBAL_LOCK;
        }
        boolean bypass = player.hasPermission("legendaryclasses.skills.bypass-cooldown");
        long remaining = cooldowns.getRemainingMillis(uuid, type);
        if (remaining > 0L && !bypass) {
            messages.send(player, "skill.cooldown", "skill", name, "time", formatSeconds(remaining));
            return CastResult.COOLDOWN;
        }
        Skill skill = skills.get(type);
        if (skill == null) {
            return CastResult.FAILED;
        }

        lastCast.put(uuid, now);
        boolean success;
        try {
            success = skill.cast(new SkillContext(plugin, this, player, type));
        } catch (RuntimeException ex) {
            plugin.getLogger().severe("Erreur dans la compétence " + type.getId() + " : " + ex);
            ex.printStackTrace();
            messages.send(player, "skill.error");
            return CastResult.FAILED;
        }
        if (!success) {
            return CastResult.FAILED;
        }
        if (!bypass) {
            double seconds = plugin.getConfig().getDouble(type.getConfigPath() + ".cooldown", 10);
            cooldowns.start(uuid, type, (long) (seconds * 1000));
        }
        player.sendActionBar(messages.component("skill.cast", "skill", name));
        return CastResult.SUCCESS;
    }

    // ---------- Furtivité (Assassin) ----------

    public void markStealth(UUID uuid, long untilMillis) {
        stealth.put(uuid, untilMillis);
    }

    public boolean isStealthed(UUID uuid) {
        Long until = stealth.get(uuid);
        if (until == null) {
            return false;
        }
        if (until <= System.currentTimeMillis()) {
            stealth.remove(uuid);
            return false;
        }
        return true;
    }

    public void breakStealth(Player player) {
        if (stealth.remove(player.getUniqueId()) != null) {
            player.removePotionEffect(PotionEffectType.INVISIBILITY);
        }
    }

    // ---------- Nettoyage ----------

    public void onQuit(UUID uuid) {
        stealth.remove(uuid);
        lastCast.remove(uuid);
        cooldowns.purgeExpired(uuid);
    }

    public static String formatSeconds(long millis) {
        return String.format(Locale.ROOT, "%.1f", millis / 1000.0);
    }

    public CooldownManager getCooldowns() { return cooldowns; }

    public Fx getFx() { return fx; }

    public Combat getCombat() { return combat; }

    public Projectiles getProjectiles() { return projectiles; }

    public SkillItemFactory getItems() { return items; }

    public SkillProtection getProtection() { return protection; }
}
