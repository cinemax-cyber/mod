package fr.legendaryclasses.skill;

import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

/** Zones sûres rectangulaires (config protection.safe-zones) où les compétences sont interdites. */
public final class SkillProtection {

    private record Zone(String world, double minX, double minZ, double maxX, double maxZ) { }

    private final Logger logger;
    private final List<Zone> zones = new ArrayList<>();

    public SkillProtection(Logger logger) {
        this.logger = logger;
    }

    public void reload(FileConfiguration config) {
        zones.clear();
        for (String line : config.getStringList("protection.safe-zones")) {
            String[] parts = line.split(";");
            if (parts.length != 5) {
                logger.warning("Zone sûre invalide (format monde;x1;z1;x2;z2) : " + line);
                continue;
            }
            try {
                double x1 = Double.parseDouble(parts[1].trim());
                double z1 = Double.parseDouble(parts[2].trim());
                double x2 = Double.parseDouble(parts[3].trim());
                double z2 = Double.parseDouble(parts[4].trim());
                zones.add(new Zone(parts[0].trim(), Math.min(x1, x2), Math.min(z1, z2),
                        Math.max(x1, x2), Math.max(z1, z2)));
            } catch (NumberFormatException ex) {
                logger.warning("Zone sûre invalide (nombres) : " + line);
            }
        }
    }

    public boolean isProtected(Location location) {
        if (zones.isEmpty() || location.getWorld() == null) {
            return false;
        }
        String world = location.getWorld().getName();
        for (Zone zone : zones) {
            if (zone.world.equalsIgnoreCase(world)
                    && location.getX() >= zone.minX && location.getX() <= zone.maxX
                    && location.getZ() >= zone.minZ && location.getZ() <= zone.maxZ) {
                return true;
            }
        }
        return false;
    }
}
