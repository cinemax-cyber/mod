package fr.legendaryclasses.skill;

import fr.legendaryclasses.classes.ClassType;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/** Catalogue des compétences. */
public enum SkillType {

    // Guerrier
    FRAPPE_PUISSANTE(ClassType.GUERRIER, "frappe_puissante", 1, false),
    ONDE_DE_CHOC(ClassType.GUERRIER, "onde_de_choc", 5, false),
    CRI_DE_GUERRE(ClassType.GUERRIER, "cri_de_guerre", 10, false),
    BERSERKER(ClassType.GUERRIER, "berserker", 20, false),
    FRAPPE_DEVASTATRICE(ClassType.GUERRIER, "frappe_devastatrice", 30, true),

    // Assassin
    DASH(ClassType.ASSASSIN, "dash", 1, false),
    INVISIBILITE(ClassType.ASSASSIN, "invisibilite", 5, false),
    TELEPORTATION(ClassType.ASSASSIN, "teleportation", 10, false),
    OMBRE_PERSISTANTE(ClassType.ASSASSIN, "ombre_persistante", 20, false),
    SERIE_DE_FRAPPES(ClassType.ASSASSIN, "serie_de_frappes", 30, true),

    // Mage
    BOULE_DE_FEU(ClassType.MAGE, "boule_de_feu", 1, false),
    PROJECTILE_DE_GLACE(ClassType.MAGE, "projectile_de_glace", 5, false),
    ECLAIR_MAGIQUE(ClassType.MAGE, "eclair_magique", 10, false),
    CERCLE_MAGIQUE(ClassType.MAGE, "cercle_magique", 20, false),
    PLUIE_DE_METEORES(ClassType.MAGE, "pluie_de_meteores", 30, true),

    // Archer
    TIR_RENFORCE(ClassType.ARCHER, "tir_renforce", 1, false),
    FLECHE_EXPLOSIVE(ClassType.ARCHER, "fleche_explosive", 5, false),
    RAFALE_DE_FLECHES(ClassType.ARCHER, "rafale_de_fleches", 10, false),
    FLECHE_TRACANTE(ClassType.ARCHER, "fleche_tracante", 20, false),
    PLUIE_DE_FLECHES(ClassType.ARCHER, "pluie_de_fleches", 30, true),

    // Faucheur
    FRAPPE_D_OMBRE(ClassType.FAUCHEUR, "frappe_d_ombre", 1, false),
    FAUX_SPECTRALE(ClassType.FAUCHEUR, "faux_spectrale", 5, false),
    DRAIN_DE_VIE(ClassType.FAUCHEUR, "drain_de_vie", 10, false),
    VORTEX(ClassType.FAUCHEUR, "vortex", 20, false),
    TEMPETE_D_OMBRES(ClassType.FAUCHEUR, "tempete_d_ombres", 30, true);

    private final ClassType classType;
    private final String id;
    private final int defaultUnlockLevel;
    private final boolean ultimate;

    SkillType(ClassType classType, String id, int defaultUnlockLevel, boolean ultimate) {
        this.classType = classType;
        this.id = id;
        this.defaultUnlockLevel = defaultUnlockLevel;
        this.ultimate = ultimate;
    }

    public ClassType getClassType() { return classType; }

    public String getId() { return id; }

    public int getDefaultUnlockLevel() { return defaultUnlockLevel; }

    public boolean isUltimate() { return ultimate; }

    /** Chemin de la compétence dans config.yml, ex. "skills.guerrier.onde_de_choc". */
    public String getConfigPath() {
        return "skills." + classType.getId() + "." + id;
    }

    public static List<SkillType> forClass(ClassType type) {
        List<SkillType> result = new ArrayList<>();
        for (SkillType skill : values()) {
            if (skill.classType == type) {
                result.add(skill);
            }
        }
        return result;
    }

    public static Optional<SkillType> fromId(String id) {
        if (id == null) {
            return Optional.empty();
        }
        for (SkillType skill : values()) {
            if (skill.id.equalsIgnoreCase(id)) {
                return Optional.of(skill);
            }
        }
        return Optional.empty();
    }
}
