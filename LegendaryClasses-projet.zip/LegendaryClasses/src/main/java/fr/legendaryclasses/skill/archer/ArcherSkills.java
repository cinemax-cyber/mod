package fr.legendaryclasses.skill.archer;

import fr.legendaryclasses.skill.Combat;
import fr.legendaryclasses.skill.Fx;
import fr.legendaryclasses.skill.Skill;
import fr.legendaryclasses.skill.SkillContext;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

public final class ArcherSkills {

    private ArcherSkills() { }

    public static void register(SkillManager manager) {
        manager.register(new Skill(SkillType.TIR_RENFORCE, ArcherSkills::tirRenforce));
        manager.register(new Skill(SkillType.FLECHE_EXPLOSIVE, ArcherSkills::flecheExplosive));
        manager.register(new Skill(SkillType.RAFALE_DE_FLECHES, ArcherSkills::rafaleDeFleches));
        manager.register(new Skill(SkillType.FLECHE_TRACANTE, ArcherSkills::flecheTracante));
        manager.register(new Skill(SkillType.PLUIE_DE_FLECHES, ArcherSkills::pluieDeFleches));
    }

    private static Location muzzle(Player p) {
        Location eye = p.getEyeLocation();
        return eye.clone().add(eye.getDirection().multiply(0.6)).subtract(0, 0.15, 0);
    }

    private static boolean tirRenforce(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double damage = c.num("damage", 12);
        fx.sound(p.getLocation(), "entity.arrow.shoot", 1f, 0.7f);
        fx.sound(p.getLocation(), "entity.player.attack.crit", 0.6f, 1.4f);
        c.projectiles().launch(p, muzzle(p), p.getEyeLocation().getDirection(), c.num("speed", 2.0),
                c.num("range", 60), 0.5, "crit", (where, direct) -> {
                    if (direct != null) {
                        combat.hit(p, direct, damage, false);
                        fx.sound(where, "entity.arrow.hit_player", 1f, 1.0f);
                    } else {
                        fx.sound(where, "entity.arrow.hit", 1f, 1.0f);
                    }
                    fx.particle(where, "crit", 18, 0.25, 0.25, 0.25, 0.3);
                    fx.particle(where, "poof", 4, 0.1, 0.1, 0.1, 0.02);
                });
        return true;
    }

    private static boolean flecheExplosive(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double damage = c.num("damage", 8);
        double radius = c.num("radius", 3);
        fx.sound(p.getLocation(), "entity.arrow.shoot", 1f, 0.6f);
        c.projectiles().launch(p, muzzle(p), p.getEyeLocation().getDirection(), c.num("speed", 1.8),
                c.num("range", 50), 0.5, "crit", (where, direct) -> {
                    for (LivingEntity target : combat.nearby(p, where, radius)) {
                        double factor = target.equals(direct) ? 1.0 : 0.75;
                        if (combat.hit(p, target, damage * factor, false)) {
                            combat.knockback(target, where, 0.8, 0.3);
                        }
                    }
                    fx.particle(where, "explosion", 1, 0, 0, 0, 0);
                    fx.particle(where, "flame", 15, 0.6, 0.4, 0.6, 0.05);
                    fx.particle(where, "smoke", 10, 0.6, 0.4, 0.6, 0.03);
                    fx.sound(where, "entity.generic.explode", 0.8f, 1.3f);
                });
        return true;
    }

    private static boolean rafaleDeFleches(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double damage = c.num("damage", 4);
        double spread = Math.max(0.001, c.num("spread", 0.05));
        double speed = c.num("speed", 2.0);
        double range = c.num("range", 40);
        c.repeat((long) c.num("interval-ticks", 3), (int) c.num("arrows", 5), i -> {
            if (!p.isOnline() || p.isDead()) {
                return false;
            }
            ThreadLocalRandom random = ThreadLocalRandom.current();
            Vector direction = p.getEyeLocation().getDirection().add(new Vector(
                    random.nextDouble(-spread, spread),
                    random.nextDouble(-spread, spread),
                    random.nextDouble(-spread, spread))).normalize();
            fx.sound(p.getLocation(), "entity.arrow.shoot", 0.8f, 1.0f + i * 0.05f);
            c.projectiles().launch(p, muzzle(p), direction, speed, range, 0.5, "crit", (where, direct) -> {
                if (direct != null) {
                    combat.hit(p, direct, damage, true);
                }
                fx.particle(where, "crit", 8, 0.2, 0.2, 0.2, 0.2);
            });
            return true;
        });
        return true;
    }

    private static boolean flecheTracante(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        LivingEntity target = combat.bestTargetInView(p, c.num("search-radius", 25), 0.3);
        if (target == null) {
            return c.fail("skill.no-target");
        }
        double damage = c.num("damage", 10);
        fx.sound(p.getLocation(), "entity.arrow.shoot", 1f, 1.3f);
        fx.sound(p.getLocation(), "entity.experience_orb.pickup", 0.8f, 1.8f);
        c.projectiles().launchHoming(p, muzzle(p), p.getEyeLocation().getDirection(), target,
                c.num("speed", 1.4), (int) c.num("max-ticks", 50), 1.2, "end_rod", (where, direct) -> {
                    if (direct != null) {
                        combat.hit(p, direct, damage, false);
                        fx.sound(where, "entity.arrow.hit_player", 1f, 1.2f);
                    }
                    fx.particle(where, "crit", 15, 0.3, 0.3, 0.3, 0.3);
                    fx.particle(where, "end_rod", 8, 0.3, 0.3, 0.3, 0.05);
                });
        return true;
    }

    private static boolean pluieDeFleches(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 6);
        double damage = c.num("damage", 4);
        int perWave = (int) c.num("arrows-per-wave", 7);
        Location center = combat.snapToGround(combat.aimPoint(p, c.num("range", 40), false));

        fx.ring(center.clone().add(0, 0.2, 0), "crit", radius, 30);
        fx.sound(p.getLocation(), "entity.arrow.shoot", 1f, 0.5f);
        c.repeat((long) c.num("interval-ticks", 8), (int) c.num("waves", 5), i -> {
            if (!p.isOnline()) {
                return false;
            }
            ThreadLocalRandom random = ThreadLocalRandom.current();
            for (int k = 0; k < perWave; k++) {
                double angle = random.nextDouble(0, Math.PI * 2);
                double distance = Math.sqrt(random.nextDouble()) * radius;
                Location impact = center.clone().add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
                fx.line(impact.clone().add(0, 14, 0), impact, "crit", 5);
                for (LivingEntity target : combat.nearby(p, impact, 1.6)) {
                    combat.hit(p, target, damage, true);
                }
                fx.particle(impact.clone().add(0, 0.2, 0), "poof", 2, 0.1, 0.1, 0.1, 0.02);
            }
            fx.sound(center, "entity.arrow.hit", 0.8f, 1.2f);
            return true;
        });
        return true;
    }
}
