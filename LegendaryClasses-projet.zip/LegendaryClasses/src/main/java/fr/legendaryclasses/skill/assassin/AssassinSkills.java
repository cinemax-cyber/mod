package fr.legendaryclasses.skill.assassin;

import fr.legendaryclasses.skill.Combat;
import fr.legendaryclasses.skill.Fx;
import fr.legendaryclasses.skill.Skill;
import fr.legendaryclasses.skill.SkillContext;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Mob;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

public final class AssassinSkills {

    private AssassinSkills() { }

    public static void register(SkillManager manager) {
        manager.register(new Skill(SkillType.DASH, AssassinSkills::dash));
        manager.register(new Skill(SkillType.INVISIBILITE, AssassinSkills::invisibilite));
        manager.register(new Skill(SkillType.TELEPORTATION, AssassinSkills::teleportation));
        manager.register(new Skill(SkillType.OMBRE_PERSISTANTE, AssassinSkills::ombrePersistante));
        manager.register(new Skill(SkillType.SERIE_DE_FRAPPES, AssassinSkills::serieDeFrappes));
    }

    private static boolean dash(SkillContext c) {
        Player p = c.player();
        Fx fx = c.fx();
        if (p.isGliding() || p.isInsideVehicle()) {
            return c.fail("skill.cannot-now");
        }
        Vector direction = p.getLocation().getDirection();
        direction.setY(0);
        if (direction.lengthSquared() < 0.01) {
            direction = p.getEyeLocation().getDirection();
        }
        direction.normalize().multiply(c.num("strength", 1.8));
        direction.setY(c.num("lift", 0.25));
        p.setVelocity(direction);
        p.setFallDistance(0f);

        fx.particle(p.getLocation().add(0, 0.5, 0), "poof", 12, 0.3, 0.3, 0.3, 0.05);
        fx.sound(p.getLocation(), "entity.bat.takeoff", 1f, 1.5f);
        c.repeat(1, 6, i -> {
            fx.particle(p.getLocation().add(0, 0.8, 0), "cloud", 4, 0.2, 0.3, 0.2, 0.02);
            return p.isOnline();
        });
        return true;
    }

    private static boolean invisibilite(SkillContext c) {
        Player p = c.player();
        Fx fx = c.fx();
        int duration = (int) (c.num("duration", 8) * 20);
        p.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, duration, 0, false, false, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration, 0, false, false, true));
        if (c.bool("break-on-attack", true)) {
            c.manager().markStealth(p.getUniqueId(), System.currentTimeMillis() + duration * 50L);
        }
        fx.particle(p.getLocation().add(0, 1, 0), "smoke", 30, 0.4, 0.7, 0.4, 0.02);
        fx.sound(p.getLocation(), "entity.illusioner.mirror_move", 1f, 1.2f);
        return true;
    }

    private static boolean teleportation(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        LivingEntity target = combat.nearestTarget(p, c.num("range", 12), true);
        if (target == null) {
            return c.fail("skill.no-target");
        }
        Location destination = combat.behind(target, 1.6);
        if (destination == null) {
            return c.fail("skill.no-space");
        }
        Location from = p.getLocation();
        fx.particle(from.clone().add(0, 1, 0), "reverse_portal", 30, 0.3, 0.6, 0.3, 0.2);
        Vector toTarget = target.getEyeLocation().toVector()
                .subtract(destination.clone().add(0, p.getEyeHeight(), 0).toVector());
        destination.setDirection(toTarget);
        p.teleport(destination);
        p.setFallDistance(0f);
        fx.particle(destination.clone().add(0, 1, 0), "portal", 30, 0.3, 0.6, 0.3, 0.3);
        fx.particle(destination.clone().add(0, 1, 0), "smoke", 15, 0.3, 0.5, 0.3, 0.02);
        fx.sound(from, "entity.enderman.teleport", 1f, 1.3f);
        fx.sound(destination, "entity.enderman.teleport", 1f, 1.0f);
        return true;
    }

    private static boolean ombrePersistante(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 4);
        int effectTicks = (int) c.num("effect-ticks", 60);
        int pulses = Math.max(1, (int) (c.num("duration", 6) * 2));
        Location center = p.getLocation().clone();

        fx.sound(center, "entity.phantom.flap", 1f, 0.6f);
        c.repeat(10, pulses, i -> {
            if (!p.isOnline()) {
                return false;
            }
            fx.ring(center.clone().add(0, 0.15, 0), "smoke", radius, 20);
            fx.particle(center.clone().add(0, 1, 0), "squid_ink", 8, radius / 2, 0.5, radius / 2, 0.01);
            for (LivingEntity target : combat.nearby(p, center, radius)) {
                target.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, effectTicks + 40, 0, false, true, true));
                target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, effectTicks, 0, false, true, true));
                target.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, Math.min(effectTicks, 30), 0, false, true, true));
                if (target instanceof Mob mob) {
                    mob.setTarget(null);
                }
            }
            return true;
        });
        return true;
    }

    private static boolean serieDeFrappes(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double range = c.num("range", 8);
        LivingEntity target = combat.findTarget(p, range);
        if (target == null) {
            target = combat.nearestTarget(p, range, true);
        }
        if (target == null) {
            return c.fail("skill.no-target");
        }
        final LivingEntity victim = target;
        Location behind = combat.behind(victim, 1.4);
        if (behind != null) {
            fx.particle(p.getLocation().add(0, 1, 0), "reverse_portal", 25, 0.3, 0.6, 0.3, 0.2);
            behind.setDirection(victim.getEyeLocation().toVector()
                    .subtract(behind.clone().add(0, p.getEyeHeight(), 0).toVector()));
            p.teleport(behind);
            fx.sound(behind, "entity.enderman.teleport", 0.8f, 1.5f);
        }
        double damage = c.num("damage-per-hit", 3);
        c.repeat((long) c.num("interval-ticks", 4), (int) c.num("hits", 8), i -> {
            if (!p.isOnline() || p.isDead() || victim.isDead() || !victim.isValid()
                    || !victim.getWorld().equals(p.getWorld())
                    || p.getLocation().distanceSquared(victim.getLocation()) > 36.0) {
                return false;
            }
            if (!combat.hit(p, victim, damage, true)) {
                return false;
            }
            Location at = victim.getBoundingBox().getCenter().toLocation(victim.getWorld());
            fx.particle(at, "sweep_attack", 1, 0.3, 0.3, 0.3, 0);
            fx.particle(at, "crit", 8, 0.3, 0.4, 0.3, 0.2);
            fx.sound(at, "entity.player.attack.sweep", 0.9f, 1.0f + i * 0.05f);
            return true;
        });
        return true;
    }
}
