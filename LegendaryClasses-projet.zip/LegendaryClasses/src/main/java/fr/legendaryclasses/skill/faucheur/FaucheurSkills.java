package fr.legendaryclasses.skill.faucheur;

import fr.legendaryclasses.skill.Combat;
import fr.legendaryclasses.skill.Fx;
import fr.legendaryclasses.skill.Skill;
import fr.legendaryclasses.skill.SkillContext;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public final class FaucheurSkills {

    private FaucheurSkills() { }

    public static void register(SkillManager manager) {
        manager.register(new Skill(SkillType.FRAPPE_D_OMBRE, FaucheurSkills::frappeDOmbre));
        manager.register(new Skill(SkillType.FAUX_SPECTRALE, FaucheurSkills::fauxSpectrale));
        manager.register(new Skill(SkillType.DRAIN_DE_VIE, FaucheurSkills::drainDeVie));
        manager.register(new Skill(SkillType.VORTEX, FaucheurSkills::vortex));
        manager.register(new Skill(SkillType.TEMPETE_D_OMBRES, FaucheurSkills::tempeteDOmbres));
    }

    private static boolean frappeDOmbre(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        LivingEntity target = combat.findTarget(p, c.num("range", 4.5));
        if (target == null || !combat.hit(p, target, c.num("damage", 7), false)) {
            return c.fail("skill.no-target");
        }
        combat.heal(p, c.num("heal", 2));
        Location at = target.getBoundingBox().getCenter().toLocation(target.getWorld());
        fx.line(p.getEyeLocation().add(0, -0.3, 0), at, "soul", 8);
        fx.particle(at, "soul", 15, 0.3, 0.4, 0.3, 0.05);
        fx.particle(at, "smoke", 12, 0.3, 0.4, 0.3, 0.03);
        fx.particle(p.getLocation().add(0, 1, 0), "heart", 2, 0.3, 0.3, 0.3, 0);
        fx.sound(at, "entity.vex.charge", 1f, 0.7f);
        fx.sound(at, "entity.player.attack.strong", 0.8f, 0.7f);
        return true;
    }

    private static boolean fauxSpectrale(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double range = c.num("range", 5);
        double halfAngle = c.num("half-angle", 60);
        double minDot = Math.cos(Math.toRadians(halfAngle));
        Vector look = p.getEyeLocation().getDirection().setY(0);
        if (look.lengthSquared() < 0.01) {
            return c.fail("skill.cannot-now");
        }
        look.normalize();

        List<LivingEntity> hits = new ArrayList<>();
        for (LivingEntity target : combat.nearby(p, p.getLocation(), range)) {
            Vector to = target.getLocation().toVector().subtract(p.getLocation().toVector()).setY(0);
            if (to.lengthSquared() < 0.01 || look.dot(to.normalize()) >= minDot) {
                hits.add(target);
            }
        }
        if (hits.isEmpty()) {
            return c.fail("skill.no-target");
        }
        double damage = c.num("damage", 8);
        for (LivingEntity target : hits) {
            combat.hit(p, target, damage, false);
            fx.particle(target.getBoundingBox().getCenter().toLocation(target.getWorld()), "soul", 8, 0.3, 0.4, 0.3, 0.05);
        }
        // Arc visuel de la faux
        Location origin = p.getLocation().add(0, 1, 0);
        for (double angle = -halfAngle; angle <= halfAngle; angle += halfAngle / 3.0) {
            Vector direction = look.clone().rotateAroundY(Math.toRadians(angle)).multiply(range * 0.8);
            Location point = origin.clone().add(direction);
            fx.particle(point, "sweep_attack", 1, 0, 0, 0, 0);
            fx.particle(point, "soul", 3, 0.2, 0.2, 0.2, 0.02);
        }
        fx.sound(p.getLocation(), "entity.player.attack.sweep", 1f, 0.6f);
        fx.sound(p.getLocation(), "entity.wither.shoot", 0.5f, 1.6f);
        return true;
    }

    private static boolean drainDeVie(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double range = c.num("range", 12);
        LivingEntity target = combat.findTarget(p, range);
        if (target == null) {
            target = combat.bestTargetInView(p, range, 0.5);
        }
        if (target == null) {
            return c.fail("skill.no-target");
        }
        final LivingEntity victim = target;
        double damage = c.num("damage-per-pulse", 3);
        double heal = c.num("heal-per-pulse", 1.5);
        double maxDistanceSquared = (range + 2) * (range + 2);

        c.repeat(10, (int) c.num("pulses", 4), i -> {
            if (!p.isOnline() || p.isDead() || victim.isDead() || !victim.isValid()
                    || !victim.getWorld().equals(p.getWorld())
                    || p.getLocation().distanceSquared(victim.getLocation()) > maxDistanceSquared
                    || !p.hasLineOfSight(victim)) {
                return false;
            }
            if (!combat.hit(p, victim, damage, true)) {
                return false;
            }
            combat.heal(p, heal);
            Location from = victim.getBoundingBox().getCenter().toLocation(victim.getWorld());
            fx.line(from, p.getEyeLocation().add(0, -0.3, 0), "soul", 10);
            fx.particle(p.getLocation().add(0, 1, 0), "heart", 1, 0.3, 0.3, 0.3, 0);
            fx.sound(from, "entity.phantom.bite", 0.6f, 0.6f);
            return true;
        });
        return true;
    }

    private static boolean vortex(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 7);
        double pull = c.num("pull", 0.35);
        double damage = c.num("damage", 1.5);
        int runs = Math.max(1, (int) (c.num("duration", 4) * 5)); // une exécution toutes les 4 ticks
        Location center = combat.snapToGround(combat.aimPoint(p, c.num("range", 15), false)).add(0, 0.5, 0);

        fx.sound(center, "entity.warden.sonic_charge", 0.8f, 1.4f);
        c.repeat(4, runs, i -> {
            if (!p.isOnline()) {
                return false;
            }
            for (LivingEntity target : combat.nearby(p, center, radius)) {
                Vector toward = center.toVector().subtract(target.getLocation().toVector());
                double distance = toward.length();
                if (distance > 0.8) {
                    toward.normalize().multiply(Math.min(pull, distance * 0.5)).setY(0.08);
                    target.setVelocity(toward);
                }
                if (i % 5 == 0) {
                    combat.hit(p, target, damage, true);
                }
            }
            // Spirale de particules
            for (int k = 0; k < 3; k++) {
                double base = i * 0.5 + k * (2 * Math.PI / 3);
                for (int s = 0; s < 4; s++) {
                    double r = radius * (1.0 - s / 4.0);
                    double angle = base + s * 0.8;
                    Location point = center.clone().add(Math.cos(angle) * r, s * 0.3, Math.sin(angle) * r);
                    fx.particle(point, s % 2 == 0 ? "soul" : "smoke", 1, 0, 0, 0, 0.01);
                }
            }
            return true;
        });
        return true;
    }

    private static boolean tempeteDOmbres(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 8);
        double damage = c.num("damage", 2.5);
        double healEach = c.num("heal-per-hit", 0.5);
        double maxHeal = c.num("max-heal-per-pulse", 3);
        int pulses = Math.max(1, (int) (c.num("duration", 6) * 2)); // une impulsion toutes les 10 ticks

        fx.sound(p.getLocation(), "entity.wither.spawn", 0.7f, 0.6f);
        c.repeat(10, pulses, i -> {
            if (!p.isOnline() || p.isDead()) {
                return false;
            }
            Location center = p.getLocation();
            int hits = 0;
            for (LivingEntity target : combat.nearby(p, center, radius)) {
                if (combat.hit(p, target, damage, true)) {
                    hits++;
                    fx.particle(target.getBoundingBox().getCenter().toLocation(target.getWorld()),
                            "soul", 4, 0.3, 0.4, 0.3, 0.03);
                }
            }
            if (hits > 0) {
                combat.heal(p, Math.min(maxHeal, hits * healEach));
            }
            Location ring = center.clone().add(0, 0.3, 0);
            fx.dustRing(ring, radius, 36, 110, 0, 150, 1.4f);
            fx.ring(ring.clone().add(0, 1.2, 0), "sculk_soul", radius * 0.6, 14);
            for (int y = 0; y < 5; y++) {
                fx.particle(center.clone().add(0, y * 0.6, 0), "smoke", 2, 0.4, 0.1, 0.4, 0.01);
            }
            if (i % 3 == 0) {
                fx.sound(center, "entity.wither.ambient", 0.6f, 0.6f);
            }
            return true;
        });
        return true;
    }
}
