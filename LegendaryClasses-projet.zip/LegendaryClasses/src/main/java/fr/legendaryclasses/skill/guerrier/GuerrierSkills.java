package fr.legendaryclasses.skill.guerrier;

import fr.legendaryclasses.skill.Combat;
import fr.legendaryclasses.skill.Fx;
import fr.legendaryclasses.skill.Skill;
import fr.legendaryclasses.skill.SkillContext;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.List;

public final class GuerrierSkills {

    private GuerrierSkills() { }

    public static void register(SkillManager manager) {
        manager.register(new Skill(SkillType.FRAPPE_PUISSANTE, GuerrierSkills::frappePuissante));
        manager.register(new Skill(SkillType.ONDE_DE_CHOC, GuerrierSkills::ondeDeChoc));
        manager.register(new Skill(SkillType.CRI_DE_GUERRE, GuerrierSkills::criDeGuerre));
        manager.register(new Skill(SkillType.BERSERKER, GuerrierSkills::berserker));
        manager.register(new Skill(SkillType.FRAPPE_DEVASTATRICE, GuerrierSkills::frappeDevastatrice));
    }

    private static boolean frappePuissante(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        LivingEntity target = combat.findTarget(p, c.num("range", 4.5));
        if (target == null || !combat.hit(p, target, c.num("damage", 10), false)) {
            return c.fail("skill.no-target");
        }
        combat.knockback(target, p.getLocation(), c.num("knockback", 0.6), 0.25);
        Location at = target.getBoundingBox().getCenter().toLocation(target.getWorld());
        fx.particle(at, "crit", 25, 0.4, 0.5, 0.4, 0.3);
        fx.particle(at, "explosion", 1, 0, 0, 0, 0);
        fx.sound(p.getLocation(), "entity.player.attack.strong", 1f, 0.8f);
        fx.sound(at, "entity.iron_golem.damage", 1f, 0.7f);
        return true;
    }

    private static boolean ondeDeChoc(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 5);
        Location center = p.getLocation();
        List<LivingEntity> targets = combat.nearby(p, center, radius);
        if (targets.isEmpty()) {
            return c.fail("skill.no-target");
        }
        for (LivingEntity target : targets) {
            combat.hit(p, target, c.num("damage", 4), false);
            combat.knockback(target, center, c.num("knockback", 1.2), 0.45);
        }
        Location ring = center.clone().add(0, 0.2, 0);
        fx.ring(ring, "cloud", radius, 28);
        fx.ring(ring, "crit", radius * 0.5, 16);
        fx.particle(ring, "explosion", 1, 0, 0, 0, 0);
        fx.sound(center, "entity.generic.explode", 0.7f, 1.3f);
        fx.sound(center, "block.anvil.land", 0.8f, 0.8f);
        return true;
    }

    private static boolean criDeGuerre(SkillContext c) {
        Player p = c.player();
        Fx fx = c.fx();
        int duration = (int) (c.num("duration", 10) * 20);
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, duration,
                (int) c.num("amplifier", 0), false, true, true));
        Location loc = p.getLocation().add(0, 1, 0);
        fx.dust(loc, 255, 60, 60, 1.6f, 30, 0.8);
        fx.ring(p.getLocation().add(0, 0.2, 0), "angry_villager", 1.5, 10);
        fx.sound(p.getLocation(), "entity.ravager.roar", 1f, 1.0f);
        return true;
    }

    private static boolean berserker(SkillContext c) {
        Player p = c.player();
        Fx fx = c.fx();
        int duration = (int) (c.num("duration", 8) * 20);
        p.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, duration,
                (int) c.num("strength-amplifier", 1), false, true, true));
        p.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, duration,
                (int) c.num("speed-amplifier", 0), false, true, true));
        int weakness = (int) (c.num("weakness-seconds", 5) * 20);
        if (weakness > 0) {
            // Contrepartie : un coup de fatigue une fois la rage retombée
            c.later(duration, () -> {
                if (p.isOnline() && !p.isDead()) {
                    p.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, weakness, 0, false, true, true));
                }
            });
        }
        Location loc = p.getLocation().add(0, 1, 0);
        fx.dust(loc, 160, 0, 0, 1.8f, 40, 0.9);
        fx.particle(loc, "flame", 25, 0.5, 0.8, 0.5, 0.05);
        fx.ring(p.getLocation().add(0, 0.2, 0), "flame", 1.8, 16);
        fx.sound(p.getLocation(), "entity.ender_dragon.growl", 0.9f, 1.4f);
        return true;
    }

    private static boolean frappeDevastatrice(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 7);
        double damage = c.num("damage", 14);
        double knockback = c.num("knockback", 1.5);
        int delay = (int) c.num("delay-ticks", 12);

        // Annonce visuelle de la zone avant l'impact
        Location warn = p.getLocation().clone().add(0, 0.2, 0);
        fx.ring(warn, "flame", radius, 40);
        fx.ring(warn, "flame", radius * 0.5, 24);
        fx.sound(p.getLocation(), "entity.iron_golem.attack", 1.2f, 0.6f);

        c.later(delay, () -> {
            if (!p.isOnline() || p.isDead()) {
                return;
            }
            Location center = p.getLocation();
            for (LivingEntity target : combat.nearby(p, center, radius)) {
                double distance = target.getLocation().distance(center);
                double falloff = 1.0 - 0.5 * Math.min(1.0, distance / radius);
                combat.hit(p, target, damage * falloff, false);
                combat.knockback(target, center, knockback, 0.7);
            }
            Location at = center.clone().add(0, 0.3, 0);
            fx.particle(at, "explosion_emitter", 1, 0, 0, 0, 0);
            fx.ring(at, "large_smoke", radius, 36);
            fx.ring(at, "crit", radius * 0.7, 28);
            fx.ring(at, "cloud", radius * 0.4, 20);
            fx.particle(at.clone().add(0, 0.5, 0), "flame", 40, radius * 0.3, 0.3, radius * 0.3, 0.05);
            fx.sound(center, "entity.generic.explode", 1.2f, 0.8f);
            fx.sound(center, "block.anvil.land", 1f, 0.6f);
        });
        return true;
    }
}
