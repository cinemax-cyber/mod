package fr.legendaryclasses.skill.mage;

import fr.legendaryclasses.skill.Combat;
import fr.legendaryclasses.skill.Fx;
import fr.legendaryclasses.skill.Skill;
import fr.legendaryclasses.skill.SkillContext;
import fr.legendaryclasses.skill.SkillManager;
import fr.legendaryclasses.skill.SkillType;
import org.bukkit.Location;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.Vector;

import java.util.concurrent.ThreadLocalRandom;

public final class MageSkills {

    private MageSkills() { }

    public static void register(SkillManager manager) {
        manager.register(new Skill(SkillType.BOULE_DE_FEU, MageSkills::bouleDeFeu));
        manager.register(new Skill(SkillType.PROJECTILE_DE_GLACE, MageSkills::projectileDeGlace));
        manager.register(new Skill(SkillType.ECLAIR_MAGIQUE, MageSkills::eclairMagique));
        manager.register(new Skill(SkillType.CERCLE_MAGIQUE, MageSkills::cercleMagique));
        manager.register(new Skill(SkillType.PLUIE_DE_METEORES, MageSkills::pluieDeMeteores));
    }

    private static boolean bouleDeFeu(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double damage = c.num("damage", 8);
        double radius = c.num("radius", 3);
        int fireTicks = (int) (c.num("fire-seconds", 3) * 20);
        Location eye = p.getEyeLocation();
        Vector direction = eye.getDirection();
        Location start = eye.clone().add(direction.clone().multiply(0.8));

        fx.sound(p.getLocation(), "entity.blaze.shoot", 1f, 0.9f);
        c.projectiles().launch(p, start, direction, c.num("speed", 1.2), c.num("range", 40), 0.7, "flame",
                (where, direct) -> {
                    for (LivingEntity target : combat.nearby(p, where, radius)) {
                        double factor = target.equals(direct) ? 1.0 : 0.7;
                        if (combat.hit(p, target, damage * factor, false)) {
                            target.setFireTicks(Math.max(target.getFireTicks(), fireTicks));
                            combat.knockback(target, where, 0.5, 0.3);
                        }
                    }
                    fx.particle(where, "explosion", 1, 0, 0, 0, 0);
                    fx.particle(where, "flame", 30, radius / 3, radius / 3, radius / 3, 0.08);
                    fx.particle(where, "smoke", 12, 0.5, 0.5, 0.5, 0.03);
                    fx.sound(where, "entity.generic.explode", 0.8f, 1.2f);
                });
        return true;
    }

    private static boolean projectileDeGlace(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double damage = c.num("damage", 6);
        double radius = c.num("radius", 2);
        int slowTicks = (int) (c.num("slow-seconds", 4) * 20);
        int slowAmplifier = (int) c.num("slow-amplifier", 2);
        Location eye = p.getEyeLocation();
        Vector direction = eye.getDirection();
        Location start = eye.clone().add(direction.clone().multiply(0.8));

        fx.sound(p.getLocation(), "entity.snowball.throw", 1f, 0.6f);
        c.projectiles().launch(p, start, direction, c.num("speed", 1.3), c.num("range", 35), 0.7, "snowflake",
                (where, direct) -> {
                    for (LivingEntity target : combat.nearby(p, where, radius)) {
                        double factor = target.equals(direct) ? 1.0 : 0.5;
                        if (combat.hit(p, target, damage * factor, false)) {
                            target.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, slowTicks,
                                    slowAmplifier, false, true, true));
                            target.setFreezeTicks(Math.min(target.getMaxFreezeTicks(), slowTicks));
                        }
                    }
                    fx.particle(where, "snowflake", 35, 0.6, 0.6, 0.6, 0.05);
                    fx.particle(where, "cloud", 10, 0.4, 0.4, 0.4, 0.02);
                    fx.sound(where, "block.glass.break", 1f, 1.4f);
                    fx.sound(where, "entity.player.hurt_freeze", 0.8f, 1.0f);
                });
        return true;
    }

    private static boolean eclairMagique(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double range = c.num("range", 30);
        LivingEntity direct = combat.findTarget(p, range);
        Location impact = direct != null
                ? direct.getLocation()
                : combat.aimPoint(p, range, true);
        if (impact == null) {
            return c.fail("skill.no-target");
        }
        double damage = c.num("damage", 9);
        double radius = c.num("radius", 2.5);
        boolean any = false;
        for (LivingEntity target : combat.nearby(p, impact, radius)) {
            double factor = target.equals(direct) ? 1.0 : 0.5;
            any |= combat.hit(p, target, damage * factor, false);
        }
        if (!any && direct == null) {
            // Foudre sur un bloc sans aucune cible : on la lance quand même (effet visuel), sans dégâts
            fx.particle(impact, "electric_spark", 10, 0.3, 0.3, 0.3, 0.3);
        }
        impact.getWorld().strikeLightningEffect(impact);
        fx.line(p.getEyeLocation().add(0, -0.3, 0), impact.clone().add(0, 1, 0), "electric_spark", 14);
        fx.particle(impact.clone().add(0, 1, 0), "electric_spark", 30, 0.6, 0.8, 0.6, 0.4);
        fx.sound(p.getLocation(), "entity.lightning_bolt.thunder", 0.6f, 1.4f);
        return true;
    }

    private static boolean cercleMagique(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 5);
        double damage = c.num("damage", 3);
        Location center = combat.snapToGround(combat.aimPoint(p, c.num("range", 20), false));

        fx.sound(center, "block.enchantment_table.use", 1f, 0.7f);
        c.repeat(20, (int) c.num("pulses", 6), i -> {
            if (!p.isOnline()) {
                return false;
            }
            Location ring = center.clone().add(0, 0.2, 0);
            fx.dustRing(ring, radius, 32, 150, 60, 255, 1.3f);
            fx.ring(ring, "enchant", radius * 0.6, 14);
            fx.particle(center.clone().add(0, 1, 0), "witch", 10, radius / 3, 0.6, radius / 3, 0.02);
            for (LivingEntity target : combat.nearby(p, center, radius)) {
                combat.hit(p, target, damage, false);
            }
            fx.sound(center, "entity.evoker.cast_spell", 0.7f, 1.0f + i * 0.05f);
            return true;
        });
        return true;
    }

    private static boolean pluieDeMeteores(SkillContext c) {
        Player p = c.player();
        Combat combat = c.combat();
        Fx fx = c.fx();
        double radius = c.num("radius", 8);
        double damage = c.num("damage", 7);
        double blast = c.num("blast-radius", 3);
        Location center = combat.snapToGround(combat.aimPoint(p, c.num("range", 30), false));

        fx.ring(center.clone().add(0, 0.2, 0), "flame", radius, 40);
        fx.sound(p.getLocation(), "entity.wither.spawn", 0.8f, 1.5f);
        c.repeat((long) c.num("interval-ticks", 6), (int) c.num("meteors", 14), i -> {
            if (!p.isOnline()) {
                return false;
            }
            ThreadLocalRandom random = ThreadLocalRandom.current();
            double angle = random.nextDouble(0, Math.PI * 2);
            double distance = Math.sqrt(random.nextDouble()) * radius;
            Location impact = center.clone().add(Math.cos(angle) * distance, 0, Math.sin(angle) * distance);
            // Traînée de la chute + marqueur d'impact, puis explosion 6 ticks plus tard
            fx.line(impact.clone().add(0, 18, 0), impact, "flame", 10);
            fx.particle(impact.clone().add(0, 0.1, 0), "lava", 3, 0.4, 0.1, 0.4, 0);
            c.later(6, () -> {
                if (!p.isOnline()) {
                    return;
                }
                for (LivingEntity target : combat.nearby(p, impact, blast)) {
                    if (combat.hit(p, target, damage, false)) {
                        target.setFireTicks(Math.max(target.getFireTicks(), 40));
                        combat.knockback(target, impact, 0.8, 0.4);
                    }
                }
                Location at = impact.clone().add(0, 0.5, 0);
                fx.particle(at, "explosion", 1, 0, 0, 0, 0);
                fx.particle(at, "flame", 25, 1.0, 0.4, 1.0, 0.05);
                fx.particle(at, "large_smoke", 8, 0.8, 0.4, 0.8, 0.02);
                fx.sound(impact, "entity.generic.explode", 0.9f, 1.0f);
            });
            return true;
        });
        return true;
    }
}
