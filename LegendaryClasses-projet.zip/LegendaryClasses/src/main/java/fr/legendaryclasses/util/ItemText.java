package fr.legendaryclasses.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.TextDecoration;

import java.util.ArrayList;
import java.util.List;

/** Textes d'objets sans l'italique par défaut de Minecraft. */
public final class ItemText {

    private ItemText() { }

    public static Component line(MessageManager messages, String legacy) {
        return messages.legacy(legacy).decoration(TextDecoration.ITALIC, false);
    }

    public static List<Component> lines(MessageManager messages, List<String> legacyLines) {
        List<Component> result = new ArrayList<>();
        for (String line : legacyLines) {
            result.add(line(messages, line));
        }
        return result;
    }
}
