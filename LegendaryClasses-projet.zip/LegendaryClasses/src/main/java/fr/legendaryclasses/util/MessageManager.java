package fr.legendaryclasses.util;

import fr.legendaryclasses.LegendaryClassesPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/** Gère messages.yml : codes couleur "&", placeholders {nom}, valeurs par défaut intégrées au JAR. */
public final class MessageManager {

    private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.legacyAmpersand();

    private final LegendaryClassesPlugin plugin;
    private FileConfiguration messages = new YamlConfiguration();

    public MessageManager(LegendaryClassesPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        File file = new File(plugin.getDataFolder(), "messages.yml");
        if (!file.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        YamlConfiguration loaded = YamlConfiguration.loadConfiguration(file);
        try (InputStream in = plugin.getResource("messages.yml")) {
            if (in != null) {
                loaded.setDefaults(YamlConfiguration.loadConfiguration(new InputStreamReader(in, StandardCharsets.UTF_8)));
            }
        } catch (IOException ex) {
            plugin.getLogger().warning("Impossible de lire les messages par défaut : " + ex.getMessage());
        }
        this.messages = loaded;
    }

    /** Texte brut (codes & conservés) avec placeholders remplacés. Paires clé/valeur. */
    public String raw(String key, Object... placeholders) {
        String text = messages.getString(key);
        if (text == null) {
            return "&c[message manquant : " + key + "]";
        }
        return apply(text, placeholders);
    }

    public List<String> rawList(String key, Object... placeholders) {
        List<String> result = new ArrayList<>();
        for (String line : messages.getStringList(key)) {
            result.add(apply(line, placeholders));
        }
        return result;
    }

    public Component component(String key, Object... placeholders) {
        return LEGACY.deserialize(raw(key, placeholders));
    }

    public Component legacy(String text) {
        return LEGACY.deserialize(text);
    }

    /** Message avec préfixe. */
    public void send(CommandSender sender, String key, Object... placeholders) {
        sender.sendMessage(LEGACY.deserialize(raw("prefix") + raw(key, placeholders)));
    }

    /** Ligne sans préfixe (texte déjà résolu, codes & autorisés). */
    public void sendLine(CommandSender sender, String legacyText) {
        sender.sendMessage(LEGACY.deserialize(legacyText));
    }

    /** Envoie chaque ligne d'une liste de messages, sans préfixe. */
    public void sendList(CommandSender sender, String key, Object... placeholders) {
        for (String line : rawList(key, placeholders)) {
            sendLine(sender, line);
        }
    }

    private static String apply(String text, Object... placeholders) {
        String result = text;
        for (int i = 0; i + 1 < placeholders.length; i += 2) {
            result = result.replace("{" + placeholders[i] + "}", String.valueOf(placeholders[i + 1]));
        }
        return result;
    }
}
