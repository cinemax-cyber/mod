package fr.legendaryclasses.util;

import org.bukkit.NamespacedKey;
import org.bukkit.Registry;
import org.bukkit.Sound;
import org.bukkit.entity.Player;

import java.util.Locale;

public final class SoundUtil {

    private SoundUtil() { }

    /** Joue un son à partir de sa clé Minecraft (ex. "entity.player.levelup"). Ignore les clés invalides. */
    public static void play(Player player, String key, float volume, float pitch) {
        if (player == null || key == null || key.isBlank()) {
            return;
        }
        NamespacedKey namespacedKey = NamespacedKey.fromString(key.trim().toLowerCase(Locale.ROOT));
        if (namespacedKey == null) {
            return;
        }
        Sound sound = Registry.SOUNDS.get(namespacedKey);
        if (sound == null) {
            return;
        }
        player.playSound(player.getLocation(), sound, volume, pitch);
    }
}
